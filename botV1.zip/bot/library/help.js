 const author = 'xazion Tyro'
 const power = 'Tyro Including'
 const help = (pushname, prefix, botName, ownerName, reqXp, getLevelingXp, getLevelingLevel, sender, _registered, uangku, role) => {
	return`
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭───────────────────────
┃│ *Nametag* : *${pushname}*
┃│
┃│ *Number* : wa.me/${sender.split("@")[0]}
┃│
┃│ *Your money* : *$${uangku}*
┃│
┃│ *total XP* : *${getLevelingXp(sender)}/${reqXp}*
┃│
┃│ *Level* : *${getLevelingLevel(sender)}*
┃│
┃│ *User Join* : *${_registered.length}*
┃│
┃│ *Rank Role* : *${role}*
┃│
┃╰────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭─────────────────────
┃│     🦊 *MEDIA MENU* 🦊
┃│ 
┃│ *${prefix}lyrics* <title>
┃│ _searching lyrics request_
┃│ 
┃│ *${prefix}ssweb* <query>
┃│ _screen shooting website by  Url_
┃│ 
┃│ *${prefix}image* <text>
┃│ _searching image by google_
┃│ 
┃│ *${prefix}nulis1*
┃│ _nulis buku contoh : *${prefix}nulis1 hi*
┃│
┃│ *${prefix}nulis2*
┃│ _nulis buku contoh : *${prefix}nulis2 hi*
┃│
┃│ *${prefix}pinterest <text>* (PREMIUM)
┃│ _searching news in pinterest_
┃│
┃╰────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭─────────────────────
┃│     🎏 *DOWNLOAD MENU* 🎏
┃│
┃│ *${prefix}ytmp3 <link>* 
┃│ _return yt to mp3_
┃│
┃│ *${prefix}ytmp4 <link>*
┃│ _return yt to mp4_
┃│
┃│ *${prefix}play <title>* (PREMIUM)
┃│ _searching song by the title_
┃│
┃│ *${prefix}joox <title>* (PREMIUM)
┃│ _return joox to mp3_
┃│ 
┃│ *${prefix}tiktok <link>* (PREMIUM)
┃│ _download tiktok vid to mp4_
┃│
┃│ *${prefix}spamcall* (PREMIUM)
┃│ _SPAM CALL EX : ${prefix}spamcall 896xxxxxx_
┃│
┃│ *${prefix}spambrutal* (PREMIUM)
┃│ _SPAM CALL EX : ${prefix}spambrutal 896xxxxx_
┃│
┃╰────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭─────────────────────
┃│     🦊 *ANIME MENU* 🦊
┃│ 
┃│ *${prefix}anime* [enable/disable]
┃│ _to activating typing enable_
┃│
┃│ *${prefix}ranime*
┃│ _return random anime_
┃│ 
┃│ *${prefix}cry*
┃│ _display sticker of cryin_
┃│
┃│ *${prefix}kiss*
┃│ _display sticker of kiss_
┃│ 
┃│ *${prefix}hug*
┃│ _display sticker of hug_
┃│
┃│ *${prefix}wibu*
┃│ _return to wibu pict_
┃│
┃│
┃╰────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭─────────────────────
┃│         ♥️ *NSFW MENU* ♥️
┃│ *${prefix}nsfw* [enable/disable]
┃│ _to activating typing enable_
┃│      
┃│ *${prefix}nfswloli* 
┃│ _return to nsfw loli_
┃│
┃│ *${prefix}nsfwloli2*
┃│ _return to nsfw loli2_
┃│ 
┃│ *${prefix}nsfwpussy* 
┃│ _return to nsfw pussy_
┃│
┃│ *${prefix}nekopoi*
┃│ _return of desc nekopoi_
┃│ 
┃│ *${prefix}blowjob*
┃│ _return of sticker blowjob_
┃│
┃│ *${prefix}bokep*
┃│ _return bokep gdrive_
┃│
┃│ *${prefix}randomhentai*
┃│ _searching random hentai_
┃│
┃│ *${prefix}ncode* (error)
┃│ _return nhentai code to pdf_
┃│
┃│ *${prefix}nsfwtrap* (maintenance)
┃│ _return to nsfw trap_
┃│
┃│ *${prefix}lewd* 
┃│ _return to lewd pict_
┃│
┃│ *${prefix}ero*
┃│ _return to ero pict_
┃│
┃│ *${prefix}nsfwyuri*
┃│ _return to yuri lewd pict_
┃│
┃│ *${prefix}nsfwneko*
┃│ _return to neko lewd pict_
┃│
┃╰────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭─────────────────────
┃│       🎲 *GAMBLING MENU* 🎲
┃│      
┃│ *${prefix}spin* (casino)
┃│ _spin 0-50_
┃│
┃│ *${prefix}push* (blackjack)
┃│ _push 1-21_
┃│ 
┃│ *${prefix}slot* (error)
┃│ _playing slot jackpot_
┃│
┃│ *${prefix}dice*
┃│ _dice 1-6_
┃│ 
┃│ *${prefix}roll* (next update)
┃│  ex : *${prefix}roll 2000*
┃│ _playing casino with bot_
┃│
┃╰────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭─────────────────────
┃│      🎀 *MAKER MENU* 🎀
┃│      
┃│ *${prefix}sticker* 
┃│ _return reply,image,vid,gif to sticker_
┃│
┃│ *${prefix}tts* <en/ind> 
┃│ _tts voice note with code (en/ind)_
┃│ 
┃│ *${prefix}toimg*
┃│ _return sticker to image_
┃│
┃│ *${prefix}pornhub*
┃│ _ex : ${prefix}pornhub porn | hub_
┃│ 
┃│ *${prefix}glitchtext*
┃│ _ex : ${prefix}glitchtext xazion_
┃│
┃│ *${prefix}textlight*
┃│ _ex : ${prefix}textlight xazion_
┃│ 
┃│ *${prefix}cquote*
┃│ _create quote by ex : ${prefix}cquote hi | xazion
┃│
┃│ *{prefix}cloudtext* 
┃│ _create cloudtext ex : ${prefix}cloudtext xazion
┃│
┃│ *${prefix}ttp*
┃│  _making word to sticker_
┃│
┃│ *${prefix}bass* (PREMIUM)
┃│  _replay mp4/mp3 to bass soundsound_
┃│
┃│ *${prefix}ninjalogo* 
┃│ _return to ninja logo_
┃│
┃│ *${prefix}hallowentext*
┃│ _return to halloweentext_
┃│
┃╰────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭─────────────────────
┃│      🎁 *FUN MENU* 🎁
┃│
┃│ *${prefix}meme* 
┃│ _return meme_
┃│
┃│ *${prefix}say*
┃│ _return say_
┃│
┃│ *${prefix}fitnah* (PREMIUM)
┃│ _fitnah your friends_
┃│    
┃│ *${prefix}afk* 
┃│ _afk do not disturb_
┃│
┃│ *${prefix}unafk*
┃│ _unafk func_
┃│
┃│ *${prefix}mining*
┃│ _EVENT auto mining money,exp_
┃│
┃│ *${prefix}rate* 
┃│ _display rate for you_
┃│ 
┃│ *${prefix}hobby*
┃│ _hobby your friends_
┃│ 
┃│ *${prefix}seberapagay*
┃│ _seberapagay your friends_
┃│ 
┃│ *${prefix}apakah*
┃│ _kerang menu_
┃│ 
┃│ *${prefix}kapankah*
┃│ _kerang menu_
┃│ 
┃│ *${prefix}bisakah*
┃│ _bisakah menu_
┃│
┃│ *${prefix}fishing* (maintenance)
┃│ _mancing menu_
┃│
┃╰────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭──────────────────────
┃│     🎎 *FRIEND MODE* 🎎
┃│     
┃│ *${prefix}mutual*
┃│ _searching user in the bot server_
┃│
┃│ *${prefix}next*
┃│ _if you want to skip u can next_
┃│
┃╰─────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭─────────────────────
┃│   🎗️ *INFORMATION MENU* 🎗️
┃│
┃│ *${prefix}leaderboard*
┃│ _showing the leaderboard in bot_
┃│
┃│ *${prefix}infogroup*
┃│ _return info group_
┃│
┃│ *${prefix}limit*
┃│ _display your limit_
┃│ 
┃│ *${prefix}buylimit*
┃│ _buy limit_
┃│
┃│ *${prefix}pay*
┃│ _transfer your money_
┃│ 
┃│ *${prefix}atm*
┃│ _your purse balance_
┃│
┃│ *${prefix}level*
┃│ _display your level_
┃│
┃│ *${prefix}giftlimit* *(PREMIUM)*
┃│ _gift limit to your friend_
┃│ _ex : *${prefix}giflimit (tag user) 1_
┃│
┃╰───────────────────
┗━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭──────────────────────
┃│        🚨 *CMD GROUP* 🚨
┃│
┃│ *${prefix}bot* [on/off]
┃│
┃│ *${prefix}antilink* [enable/disable]
┃│
┃│ *${prefix}leveling* [enable/disable]
┃│ 
┃│ *${prefix}welcome* [enable/disable]
┃│
┃│ *${prefix}group* [open/closed]
┃│ _auto open/closed group_
┃│
┃│ ${prefix}delete* (reply message)
┃│
┃│ *${prefix}hidetag* (ADMIN)
┃│ _display of hidetag_
┃│
┃│ *${prefix}hideping* (PREMIUM)
┃│ _hidetag Premium Version_
┃│
┃│ *${prefix}infogroup* 
┃│ _display information about group_
┃│
┃│ *${prefix}linkgroup* 
┃│ _display the link group_
┃│ 
┃│ *${prefix}ping*
┃│ _ping to all members_
┃│
┃│ *${prefix}ping1* (PREMIUM)
┃│ _premium version_
┃│ 
┃│ *${prefix}setpictgroup*
┃│ _auto set pict group_
┃│
┃│ *${prefix}add*
┃│_add (number with no + and -)_
┃│ 
┃│ *${prefix}kick*
┃│ _kick (@taguser)_
┃│
┃│ *${prefix}setgroupdesc*
┃│ _auto set group description_
┃│
┃│ *${prefix}setgroupname*
┃│ _auto set group name_
┃│
┃│ *${prefix}demote <@user>*
┃│ _auto demote admin_
┃│
┃│ *${prefix}promote <@user>*
┃│ _auto promote admin_
┃│ 
┃│ *${prefix}admin*
┃│ _list of admin_
┃│ 
┃╰─────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭──────────────────────
┃│        🐸 *OWNER MENU* 🐸
┃│
┃│ *${prefix}oadd*
┃│
┃│ *${prefix}okick*
┃│    
┃│ *${prefix}bc*
┃│
┃│ *${prefix}bcgroup*
┃│
┃│ *${prefix}kickall*
┃│
┃│ *${prefix}oping*
┃│
┃│ *${prefix}owelcome* [enable/disable]
┃│
┃│ *${prefix}oleveling* [enable/disable]
┃│
┃│ *${prefix}oantilink* [enable/disable]
┃│
┃│ *${prefix}setreply*
┃│
┃│ *${prefix}setprefix*
┃│
┃│ *${prefix}clearall*
┃│
┃│ *${prefix}block*
┃│
┃│ *${prefix}unblock*
┃│
┃│ *${prefix}leave*
┃│
┃│ *${prefix}event* [enable/disable]
┃│
┃│ *${prefix}clone*
┃│
┃│ *${prefix}setpictbot*
┃│
┃╰────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━
┏━━━━━━━♡ *TYRO BOT* ♡━━━━━━━
┃╭──────────────────────
┃│ *Author* :  *${author}*
┃│
┃│ *Developer : *${author}*
┃│
┃│ *License* : *Unlicense by Tyro Including*
┃│
┃│ *Powered By* : *${power}*
┃╰──────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help