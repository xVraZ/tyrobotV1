/*all list tag
++++++++UNLICENSE++++++++
#by xazion Developer
-REGISTER WRITER
-MENU FILTER
-DOWNLOAD MENU
-MAKER MENU
-ALL LIST COMMAND
-FUN MENU
-TOOLS MENU
-NSFW MENU
-GRAMBLING MENU
-INFO MENU
-SOSMED MENU
-STALKER MENU
-PARAMETER MENU
-ADMIN MENU
-OWNER MENU
-AFK MENU
*/
 const {
   WAConnection,
   MessageType,
   Presence,
   MessageOptions,
   Mimetype,
   WALocationMessage,
   WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   GroupSettingChange,
   waChatKey,
   mentionedJid,
   processTime,
} = require("@adiwajshing/baileys")
const qrcode = require("qrcode-terminal") 
const moment = require("moment-timezone") 
const fs = require("fs") 
const crypto = require('crypto')
const imageToBase64 = require('image-to-base64')
const base64Img = require('base64-img')
const fetch = require('node-fetch')
const axios = require('axios')
const { color, bgcolor } = require('./library/color')
const { fetchJson } = require('./library/fetcher')
const { recognize } = require('./library/ocr')
const { exec } = require("child_process")
const { wait, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./library/functions')
const tiktod = require('tiktok-scraper')
const speed = require('performance-now')
const brainly = require('brainly-scraper')
const ffmpeg = require('fluent-ffmpeg')
const imgbb = require('imgbb-uploader')
const cd = 4.32e+7
const { removeBackgroundFromImageFile } = require('remove.bg')
const { tyro } = require('./@tyro')
/*********************************FUNCTION KEY*********************************/
const SettingKey = JSON.parse(fs.readFileSync('./SettingKey/key.json'))
const beer = "'"
const {
    Vinzapi,
    apivhtear,
    tobzapi,
    lolhuman,
    zeksapi,
    Apiarugaz,
    botName,
    ownerName,
    XteamKey,
    ownerNumber,
    botPrefix,
    Glimit,
    Ulimit,
    CrTyro,
    nameo,
    TyroApi,
    sinkeys
} = SettingKey
/*********************** END OF FUNCTION KEY *********************/
prefix = botPrefix
ator = sinkeys
blocked = []   
limitawal = Ulimit
memberlimit = Glimit
cr = CrTyro
namo = nameo
/************** ASYNC FILE JSON LOADER ***************/
const animes = JSON.parse(fs.readFileSync('./DB/anime/anime.json'))
const setiker = JSON.parse(fs.readFileSync('./DB/stik.json'))
const _leveling = JSON.parse(fs.readFileSync('./DB/group/leveling.json'))
const _level = JSON.parse(fs.readFileSync('./DB/user/level.json'))
const _registered = JSON.parse(fs.readFileSync('./DB/user/registered.json'))
const welkom = JSON.parse(fs.readFileSync('./DB/group/welkom.json'))
const nsfw = JSON.parse(fs.readFileSync('./DB/group/nsfw.json'))
const event = JSON.parse(fs.readFileSync('./DB/group/event.json'))
const _limit = JSON.parse(fs.readFileSync('./DB/user/limit.json'))
const uang = JSON.parse(fs.readFileSync('./DB/user/uang.json'))
const ban = JSON.parse(fs.readFileSync('./DB/user/banned.json'))
const premium = JSON.parse(fs.readFileSync('./DB/user/premium.json'))
const publik = JSON.parse(fs.readFileSync('./DB/group/public.json'))
const antilink = JSON.parse(fs.readFileSync('./DB/group/antilink.json'))
const badword = JSON.parse(fs.readFileSync('./DB/group/badword.json'))
const bad = JSON.parse(fs.readFileSync('./DB/group/bad.json'))
/***************LOAD END FILE ASYNC****************/
const { help } = require('./library/help')
/******************ADD FUNCTION***************/
const getLevelingXp = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].xp
            }
        }

        const getLevelingLevel = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].level
            }
        }

        const getLevelingId = (sender) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].id
            }
        }

        const addLevelingXp = (sender, amount) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _level[position].xp += amount
                fs.writeFileSync('./DB/user/level.json', JSON.stringify(_level))
            }
        }

        const addLevelingLevel = (sender, amount) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _level[position].level += amount
                fs.writeFileSync('./DB/user/level.json', JSON.stringify(_level))
            }
        }

        const addLevelingId = (sender) => {
            const obj = {id: sender, xp: 1, level: 1}
            _level.push(obj)
            fs.writeFileSync('./DB/user/level.json', JSON.stringify(_level))
        }
             
         const getRegisteredRandomId = () => {
            return _registered[Math.floor(Math.random() * _registered.length)].id
        }

        const addRegisteredUser = (userid, sender, age, time, serials) => {
            const obj = { id: userid, name: sender, age: age, time: time, serial: serials }
            _registered.push(obj)
            fs.writeFileSync('./DB/user/registered.json', JSON.stringify(_registered))
        }

        const createSerial = (size) => {
            return crypto.randomBytes(size).toString('hex').slice(0, size)
        }

        const checkRegisteredUser = (sender) => {
            let status = false
            Object.keys(_registered).forEach((i) => {
                if (_registered[i].id === sender) {
                    status = true
                }
            })
            return status
        }
        
        const addATM = (sender) => {
        	const obj = {id: sender, uang : 0}
            uang.push(obj)
            fs.writeFileSync('./DB/user/uang.json', JSON.stringify(uang))
        }
        
        const addKoinUser = (sender, amount) => {
            let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang += amount
                fs.writeFileSync('./DB/user/uang.json', JSON.stringify(uang))
            }
        }
        
        const checkATMuser = (sender) => {
        	let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                return uang[position].uang
            }
        }
        
        const bayarLimit = (sender, amount) => {
        	let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit -= amount
                fs.writeFileSync('./DB/user/limit.json', JSON.stringify(_limit))
            }
        }
        	
        const confirmATM = (sender, amount) => {
        	let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === sender) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang -= amount
                fs.writeFileSync('./DB/user/uang.json', JSON.stringify(uang))
            }
        }
        
         const limitAdd = (sender) => {
             let position = false
            Object.keys(_limit).forEach((i) => {
                if (_limit[i].id == sender) {
                    position = i
                }
            })
            if (position !== false) {
                _limit[position].limit += 1
                fs.writeFileSync('./DB/user/limit.json', JSON.stringify(_limit))
            }
        }

function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);

  //return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)
  return `${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik`
}

 function addMetadata(packname, author) {	
	if (!packname) packname = '@TexBOT'; if (!author) author = 'Tyro Including';	
	author = author.replace(/[^a-zA-Z0-9]/g, '');	
	let name = `${author}_${packname}`
	if (fs.existsSync(`./${name}.exif`)) return `./${name}.exif`
	const json = {	
		"sticker-pack-name": packname,
		"sticker-pack-publisher": author,
	}
}
/*****************CLIENT FUNCTION**********/
const xazion = new WAConnection()
   xazion.on('qr', qr => {
   qrcode.generate(qr, { small: true })
   console.log(color('[','white'),color('∆','red'),color(']','white'),color('qr ready scan.','white'),color('TYRO','red'),color('ENERGY','white'),color('xazion','blue'))
})

xazion.on('credentials-updated', () => {
	const authInfo = xazion.base64EncodedAuthInfo()
   console.log(`credentials updated!`)
   fs.writeFileSync('./tyro.json', JSON.stringify(authInfo, null, '\t'))
})
fs.existsSync('./tyro.json') && xazion.loadAuthInfo('./tyro.json')
xazion.connect();
/******************WELCOME GROUP FUNCTION***************/
xazion.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {		
			const mdata = await xazion.groupMetadata(anu.jid)			
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				try {
					ppimg = await xazion.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = ` Hello @${num.split('@')[0]} 🐿️, 
				
	Welcome to Group *${mdata.subject}*  
	
➸ please read all the descriptions and enjoy in this group
				`
				let buff = await getBuffer(ppimg)
				xazion.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} else if (anu.action == 'remove') {
				num = anu.participants[0]
				try {
					ppimg = await xazion.getProfilePicture(`${num.split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `Good Bye *@${num.split('@')[0]}.....👋* 
				_I hope you come back again_`
				let buff = await getBuffer(ppimg)
				xazion.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})
/***************BLOCK FUNC*************/
xazion.on('CB:Blocklist', json => {
		if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})
/***********************IDENTITY FUNCTION*****************/
	xazion.on('message-new', async (mek) => {
		try {
			if (!mek.message) return
			if (mek.key && mek.key.remoteJid == 'status@broadcast') return
			if (mek.key.fromMe) return
			global.prefix
			global.blocked
			const content = JSON.stringify(mek.message)
			const from = mek.key.remoteJid
			const type = Object.keys(mek.message)[0]
			const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
			const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
			const timi = moment.tz('Asia/Jakarta').add(30, 'days').calendar();
			const timu = moment.tz('Asia/Jakarta').add(20, 'days').calendar();
   body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption.startsWith(prefix) ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption.startsWith(prefix) ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text.startsWith(prefix) ? mek.message.extendedTextMessage.text : ''
			budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
   var tas = (type === 'conversation' && mek.message.conversation) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text ? mek.message.extendedTextMessage.text : ''
   var pes = (type === 'conversation' && mek.message.conversation) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text ? mek.message.extendedTextMessage.text : ''
			const messagesC = pes.slice(0).trim().split(/ +/).shift().toLowerCase()
			const mesejAnti = tas.slice(0).trim().split(/ +/).shift().toLowerCase()
			const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
			const args = body.trim().split(/ +/).slice(1)
			const isCmd = body.startsWith(prefix)
			const tescuk = ["0@s.whatsapp.net"]
			const isGroup = from.endsWith('@g.us')
			const q = args.join(' ')
			const botNumber = xazion.user.jid
			const sender = isGroup ? mek.participant : mek.key.remoteJid
			pushname = xazion.contacts[sender] != undefined ? xazion.contacts[sender].vname || xazion.contacts[sender].notify : undefined
			const groupMetadata = isGroup ? await xazion.groupMetadata(from) : ''
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupDesc = isGroup ? groupMetadata.desc : ''
   const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''

/**************SECURITY ALERT CMD******************/
const isAnime = isGroup ? animes.includes(from) : false
const isBadWord = isGroup ? badword.includes(from) : false
const isEventon = isGroup ? event.includes(from) : false
const isRegistered = checkRegisteredUser(sender)
const isBanned = ban.includes(sender) 
const isPublic = isGroup ? publik.includes(from) : false
const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
const isLevelingOn = isGroup ? _leveling.includes(from) : false
const isGroupAdmins = groupAdmins.includes(sender) || false
const isWelkom = isGroup ? welkom.includes(from) : false
const isNsfw = isGroup ? nsfw.includes(from) : false
const isAntiLink = isGroup ? antilink.includes(from) : false
const isOwner = ownerNumber.includes(sender)
const isPrem = premium.includes(sender) 
const isImage = type === 'imageMessage'
const isUrl = (url) => {
			    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
			const reply = (teks) => {
				xazion.sendMessage(from, teks, text, {quoted:mek})
			}
			const sendMess = (hehe, teks) => {
				xazion.sendMessage(hehe, teks, text)
			}
			const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? xazion.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : xazion.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": memberr}})
			}
			const sendImage = (teks) => {
		    xazion.sendMessage(from, teks, image, {quoted:mek})
		    }
		    const costum = (pesan, tipe, target, target2) => {
			xazion.sendMessage(from, pesan, tipe, {quoted: { key: { fromMe: false, participant: `${target}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target2}` }}})
			}
		    const sendPtt = (teks) => {
		    xazion.sendMessage(from, audio, mp3, {quoted:mek})
		    }
/**************RANK ROLE****************/
const levelRole = getLevelingLevel(sender)
   	     var role = 'Trainee'
   	     if (levelRole <= 3) {
   	         role = 'BlackSmith'
   	     } else if (levelRole <= 5) {
   	         role = 'BetSilver'
   	     } else if (levelRole <= 10) {
   	         role = 'GoldSmith'
   	     } else if (levelRole <= 15) {
   	         role = 'Diamond'
   	     } else if (levelRole <= 20) {
   	         role = 'Diamond l'
   	     } else if (levelRole <= 25) {
   	         role = 'Diamond II'
   	     } else if (levelRole <= 30) {
   	         role = 'Diamond IIl'
   	     } else if (levelRole <= 35) {
   	         role = 'Platinum Sin l'
   	     } else if (levelRole <= 40) {
   	         role = 'Platinum Sin II'
   	     } else if (levelRole <= 45) {
   	         role = 'Platinum Sin III'
   	     } else if (levelRole <= 50) {
   	         role = 'Platinum Sin IV'
   	     } else if (levelRole <= 55) {
   	         role = 'Adamantine Class I'
   	     } else if (levelRole <= 60) {
   	         role = 'Adamantine Class II'
   	     } else if (levelRole <= 70) {
   	         role = 'Adamantine Class III'
   	     } else if (levelRole <= 80) {
   	         role = 'Adamantine Class IV'
   	     } else if (levelRole <= 90) {
   	         role = 'Adamantine Class V'
   	     } else if (levelRole <= 100) {
   	         role = '3nd Sage'
   	     } else if (levelRole <= 150) {
   	         role = '2nd Sage eldian'
   	     } else if (levelRole <= 200) {
   	         role = '1nd Sage master'
   	     } else if (levelRole <= 300) {
   	         role = 'Sage Grand Master'
   	     }
/*******************LEVELING FUNCTION*******************/
 if (isGroup && isRegistered && isLevelingOn) {
            const currentLevel = getLevelingLevel(sender)
            const checkId = getLevelingId(sender)
            try {
 if (currentLevel === undefined && checkId === undefined) addLevelingId(sender)
            const amountXp = Math.floor(Math.random() * 1) + 1000
            const requiredXp = 5000 * (Math.pow(2, currentLevel) - 1)
            const getLevel = getLevelingLevel(sender)
            addLevelingXp(sender, amountXp)
            if (requiredXp <= getLevelingXp(sender)) {
            addLevelingLevel(sender, 1)
            bayarLimit(sender, 3)
            await reply(tyro.levelup(pushname, sender, getLevelingXp,  getLevel, getLevelingLevel ,role))
                }
            } catch (err) {
                console.error(err)
            }
        }
/***********************FUNCTION LIMIT*******************/
const checkLimit = (sender) => {
          	let found = false
                    for (let lmt of _limit) {
                        if (lmt.id === sender) {
                            let limitCounts = limitawal - lmt.limit
                            if (limitCounts <= 0) return xazion.sendMessage(from,``, text,{ quoted: mek})
                            xazion.sendMessage(from, tyro.limitcount(limitCounts), text, { quoted : mek})
                            found = true
                        }
                    }
                    if (found === false) {
                        let obj = { id: sender, limit: 0 }
                        _limit.push(obj)
                        fs.writeFileSync('./DB/user/limit.json', JSON.stringify(_limit))
                        xazion.sendMessage(from, tyro.limitcount(limitCounts), text, { quoted : mek})
                    }
				}

  const isLimit = (sender) =>{ 
		      let position = false
              for (let i of _limit) {
              if (i.id === sender) {
              	let limits = i.limit
              if (limits >= limitawal ) {
              	  position = true
                    xazion.sendMessage(from, tyro.limitend(pushname), text, {quoted: mek})
                    return true
              } else {
              	_limit
                  position = true
                  return false
               }
             }
           }
           if (position === false) {
           	const obj = { id: sender, limit: 0 }
                _limit.push(obj)
                fs.writeFileSync('./DB/user/limit.json',JSON.stringify(_limit))
           return false
       }
     }

        
            if (isGroup) {
				try {
					const getmemex = groupMembers.length
					    if (getmemex <= memberlimit) {
                            xazion.groupLeave(from)
					    }
		       } catch (err) { console.error(err)  }
        }
        
/*******************ATM FUNCTION**********/
  if (isRegistered ) {
            const checkATM = checkATMuser(sender)
            try {
                if (checkATM === undefined) addATM(sender)
                const uangsaku = Math.floor(Math.random() * 10) + 90
                addKoinUser(sender, uangsaku)
            } catch (err) {
                console.error(err)
            }
        }
 /*************BADWORD FUNCTION**************/
const hassed = "'"
  var kicek = `${sender.split("@")[0]}@s.whatsapp.net`
  	   	if (isGroup && isBadWord) {
            if (bad.includes(messagesC)) {
                if (!isGroupAdmins) {
                    try { 
                        reply("DETECTED ILEGAL BADWORD!! 😠")
                        setTimeout( () => {
 	                           xazion.groupRemove(from, [kicek]).catch((e)=>{reply(`BOT MUST ADMIN`)})
							}, 4000)
								setTimeout( () => {
								xazion.updatePresence(from, Presence.composing)
								reply("*「 ANTI BADWORD 」*\nHas been kicked because CHAT BADWORD!")
							}, 0)
                        } catch { xazion.sendMessage(from, `the bot is not admin can${hassed}t kick the user !`, text , {quoted : mek}) }
                } else {
                    return reply( "*Because you are admin you will not be kicked*")
                }
            }
        }
        
/******************ANTI LINK FUNC*********/
if (mesejAnti.includes("://chat.whatsapp.com/")){
		        if (!isGroup) return
		        if (!isAntiLink) return
		        if (isGroupAdmins) return reply('*because you are admin you will not be kicked*')
		        xazion.updatePresence(from, Presence.composing)
		        if (mesejAnti.includes("#izin")) return reply("message received")
		        var kic = `*${sender.split("@")[0]}@s.whatsapp.net*`
		        reply(`*Warn to ${sender.split("@")[0]} do not send WhatsApp group link*`)
		        setTimeout( () => {
			        xazion.groupRemove(from, [kic]).catch((e)=>{reply(`*BOT MUST ADMIN*`)})
		        }, 3000)
		        setTimeout( () => {
			        xazion.updatePresence(from, Presence.composing)
			        reply("byee...")
		        }, 0)
	        }               
/******************END ALL FUNCTION*******************/
/*****************CONSOLE LOG*****,*****************/        
			colors = ['red','white','black','blue','yellow','green']
			const isMedia = (type === 'imageMessage' || type === 'videoMessage')
			const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
			const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
			const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
			if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
/**********************END LOAD******************/
switch(command) {

/****************REGISTER WRITER**************/
case 'register':
  if (isPublic) return reply(tyro.botoff()) 
				if (isBanned) return reply(tyro.bUser())
                if (isRegistered) return  reply(tyro.rediregis())
                if (!q.includes('|')) return  reply(tyro.wrongf())
                const namaUser = q.substring(0, q.indexOf('|') - 0)
                const umurUser = q.substring(q.lastIndexOf('|') + 1)
                const serialUser = createSerial(20)
                const bisser = "'"
                if(isNaN(umurUser)) return await reply('only age number can allowed!!')
                if (namaUser.length >= 30) return reply(`why is your name so long it${bisser}s a name or a train`)
                if (umurUser > 40) return reply(`your age is too  old maximum 40 years`)
                if (umurUser < 12) return reply(`your age is too young minimum 12 years`)
            try {
      ppimg = await xazion.getProfilePicture(`${sender.split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
                veri = sender
                if (isGroup) {
                    addRegisteredUser(sender, namaUser, umurUser, time, serialUser)
                    await xazion.sendMessage(from, ppimg, image, {quoted: mek, caption: tyro.registered(namaUser, umurUser, serialUser, time, sender)})
                    addATM(sender)
                    addLevelingId(sender)
                    checkLimit(sender)
                    console.log(color('[REGISTER]'), color(time, 'yellow'), 'Name:', color(namaUser, 'cyan'), 'Age:', color(umurUser, 'cyan'), 'Serial:', color(serialUser, 'cyan'), 'in', color(sender || groupName))
                } else {
                    addRegisteredUser(sender, namaUser, umurUser, time, serialUser)
                    await xazion.sendMessage(from, ppimg, image, {quoted: mek, caption: tyro.registered(namaUser, umurUser, serialUser, time, sender)})
                    addATM(sender)
                    addLevelingId(sender)
                    checkLimit(sender)
                    console.log(color('[REGISTER]'), color(time, 'yellow'), 'Name:', color(namaUser, 'cyan'), 'Age:', color(umurUser, 'cyan'), 'Serial:', color(serialUser, 'cyan'))
                }
				break
/***************************END LOAD OFF REGISTER WRITER*************************/
/********************************MENU FILTER******************************/
    case 'help':
    case 'menu':
                if (isPublic) return reply(tyro.botoff())					
                if (isBanned) return reply(tyro.bUser())
                if (isLimit(sender)) return reply(tyro.limitend(pusname))
				if (!isRegistered) return reply(tyro.noregis())
				    const reqXp  = 5000 * (Math.pow(2, getLevelingLevel(sender)) - 1)
				    const uangku = checkATMuser(sender)
					await costum(help(pushname, prefix, botName, ownerName, reqXp, getLevelingXp, getLevelingLevel, sender, _registered, uangku, role), text, tescuk, cr, bot)
					break
/***********DOWNLOAD MENU*********/
           case 'ytmp4':
     if (isPublic) return reply(tyro.botoff())                
     if (isBanned) return reply(tyro.bUser())      
		 		if (!isRegistered) return reply(tyro.noregis())
				 if (isLimit(sender)) return reply(tyro.limitend(pushname))
					if (args.length < 1) return reply('where is the url?')
					if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply(tyro.stikga())
					anu = await fetchJson(`https://st4rz.herokuapp.com/api/ytv2?url=${args[0]}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					teks = `*Title* : ${anu.title}`
					thumb = await getBuffer(anu.thumb)
					xazion.sendMessage(from, thumb, image, {quoted: mek, caption: teks})
					buffer = await getBuffer(anu.result)
					xazion.sendMessage(from, buffer, video, {mimetype: 'video/mp4', filename: `${anu.title}.mp4`, quoted: mek})
					await limitAdd(sender)    
            break             
            case 'image':
  if (isPublic) return reply(tyro.botoff())				
  	if (args.length < 1) return reply('*What do you want to search? example : ${prefix}image kurumi*')
						if (!isPrem) return reply(tyro.premium())
					goo = body.slice(7)
					anu = await fetchJson(`https://api.vhtear.com/googleimg?query=${goo}&apikey=${apivhtear}`, {method: 'get'})
					reply(tyro.wait)
				    var pol = JSON.parse(JSON.stringify(anu.result.result_search));
                    var tes2 =  pol[Math.floor(Math.random() * pol.length)];
					pint = await getBuffer(tes2)
					xazion.sendMessage(from, pint, image, { caption: '*Google Image*\n\n*Search result : '+goo+'*', quoted: mek })
					await limitAdd(sender)    
            break
   
            /*  case 'ytmp4':
                                    if (isPublic) return reply(tyro.botoff())  	
                                    if (isBanned) return reply(tyro.bUser())
                                   	if (!isRegistered) return reply(tyro.noregis())
                                    if (isLimit(sender)) return reply(tyro.limitend(pusname))
                               					if (args.length < 1) return reply('where is the url?')
	                               				if (!isUrl(args[0]) && !args[0].includes('youtu.be')) return reply(tyro.error.Iv)
	                				anu = await fetchJson(`https://api.vhtear.com/ytdl?link=${args[0]}&apikey=${apivhtear}`, {method: 'get'})
                					if (anu.error) return reply(anu.error)
                					ytt = `「 *YOUTUBE MP4 DOWNLOADER* 」\n\n• Title : *${anu.result.title}*\n• *Size:* ${anu.result.size}\n• *Link:* https://www.youtu.be/${anu.result.id}\n\n Tunggu Sebentar 1 menit Mungkin Agak Lama Karna Mendownload Video`
                					buff = await getBuffer(anu.result.imgUrl)
	                				reply(tyro.wait)
	                				buffer = await getBuffer(anu.result.UrlVideo)
                				xazion.sendMessage(from, buff, image, {quoted: mek, caption: ytt})
                				xazion.sendMessage(from, buffer, video, {mimetype: 'video/mp4', filename: `${anu.result.title}.mp4`, quoted: mek, caption: 'Nih Anjim'})                            				
	               await limitAdd(sender) 
		             break */
	   case 'ytmp3':
                 if (isPublic) return reply(tyro.botoff())			
            	    if (!isRegistered) return reply(tyro.noregis())
                 if (isLimit(sender)) return reply(tyro.limitend(pusname))
					if (args.length < 1) return reply('where is the url?')
					if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply('url is not valid')
					anu = await fetchJson(`https://api.vhtear.com/ytdl?link=${args[0]}&apikey=${apivhtear}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					yta = `「 *YOUTUBE MP3 DOWNLOADER* 」\n\n• Title : *${anu.result.title}*\n• *Size:* ${anu.result.size}\n• *Link:* https://www.youtu.be/${anu.result.id}n\n Tunggu Sebentar 1 menit Mungkin Agak Lama Karna Mendownload Video`
					buff = await getBuffer(anu.result.imgUrl)
					reply(tyro.wait)
					buffer = await getBuffer(anu.result.UrlMp3)
					xazion.sendMessage(from, buff, image, {quoted: mek, caption: yta})
					xazion.sendMessage(from, buffer, audio, {mimetype: 'audio/mp4', filename: `${anu.result.title}.mp3`, quoted: mek, caption: 'Lugumu jelek gayn'})
		await limitAdd(sender) 
			break     
			
		case 'play': //PREMIUM USER ADD ONLY
	    case 'p':
                 if (isPublic) return reply(tyro.botoff())				
                 if (isPublic) return reply(tyro.botoff())  
                 if (isBanned) return reply(tyro.bUser())
            	 if (!isRegistered) return reply(tyro.noregis())
                 if (!isPrem) return reply(tyro.premium())
                 if (isLimit(sender)) return reply(tyro.limitend(pusname))
        reply(tyro.wait())
                 anu = await fetchJson(`https://api.xteam.xyz/dl/play?lagu=${body.slice(6)}&APIKEY=${XteamKey}`)
                 if (anu.error) return reply(anu.error)
                 infomp3 = `*➸ Title : ${anu.judul}\n➸ Size : ${anu.size}*`
                 bumfer = await getBuffer(anu.thumbnail)
                 lamgu = await getBuffer(anu.url)
                 xazion.sendMessage(from, bumfer, image, {quoted: mek, caption: infomp3})
                 xazion.sendMessage(from, lamgu, audio, {mimetype: 'audio/mp4', quoted: mek})
                await limitAdd(sender)
             break
         case 'pinterest': //ADD PREMIUM LIST
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					if (!isPrem) return reply(tyro.premium())
					xazion.updatePresence(from, Presence.composing) 
					data = await fetchJson(`https://api.fdci.se/rep.php?gambar=${body.slice(11)}`, {method: 'get'})
					reply(tyro.wait())
					n = JSON.parse(JSON.stringify(data));
					nimek =  n[Math.floor(Math.random() * n.length)];
					pok = await getBuffer(nimek)
					xazion.sendMessage(from, pok, image, { quoted: mek, caption: `*⟪ PINTEREST ⟫*`})
					await limitAdd(sender)
					break     
/**************************MAKER MENU*********************/
    case 'cquote':
                    if (isPublic) return reply(tyro.botoff())             
                    if (isBanned) return reply(tyro.bUser())
                    if (!isRegistered) return reply(tyro.noregis())
                    if (isLimit(sender)) return reply(tyro.limitend(pusname))
                                var gh = body.slice(8)
               					var quote = gh.split("|")[0];
               					var wm = gh.split("|")[1];
               					const pref = `what do you want to quote?\n\nexample : ${prefix}cquote xVraz | tyro including`
		               			if (args.length < 1) return reply(pref)
			               		reply(tyro.wait())
	               				anu = await fetchJson(`https://terhambar.com/aw/qts/?kata=${quote}&author=${wm}&tipe=random`, {method: 'get'})
               					buffer = await getBuffer(anu.result)
               					xazion.sendMessage(from, buffer, image, {caption: 'Success..✅', quoted: mek})
               				await limitAdd(sender)
               			break
			 case 's': 
				case 'stiker':
				case 'sticker': 
				            if (isPublic) return reply(tyro.botoff())             
                            if (isBanned) return reply(tyro.bUser())
                            if (!isRegistered) return reply(tyro.noregis())
            				if (isLimit(sender)) return reply(tyro.limitend(pusname))
            			await limitAdd(sender)
	           				if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
	          					const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
	          					const media = await xazion.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								reply(tyro.stikga)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata(namo, ator)} ${ran} -o ${ran}`, async (error) => {
									//if (error) {
											// reply(tyro.stikga())
											// fs.unlinkSync(media)	
											// fs.unlinkSync(ran)
											// }
									xazion.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)	
									fs.unlinkSync(ran)	
								})
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await xazion.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						reply(tyro.wait())
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(`❌ Failed, when converting $ {type} to stickers`)
							})
							.on('end', function () {
								console.log('Finish')
								exec(`webpmux -set exif ${addMetadata(namo, ator)} ${ran} -o ${ran}`, async (error) => {
									//if (error) {
											// reply(tyro.stikga())
											// fs.unlinkSync(media)	
											// fs.unlinkSync(ran)
											// }
									xazion.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
									fs.unlinkSync(media)
									fs.unlinkSync(ran)
								})
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else {
						reply(`Send picture/video/gif with caption\n${prefix}sticker (video sticker duration is 1-9 seconds)`)
					}
					break
			case 'ttp': 
     		    	if (isPublic) return reply(tyro.botoff())             
                    if (isBanned) return reply(tyro.bUser())
       				if (!isRegistered) return reply(tyro.noregis())
       				if (!isPrem) return reply(tyro.premium())
       				if (isLimit(sender)) return reply(tyro.limitend(pusname))
       				if (args.length < 1) return reply(`Teksnya mana kak? Contoh : ${prefix}nulis1 xazion baik hati`)
							pngttp = './temp/ttp.png'
							webpng = './temp/ttp.webp'
							const ttptext = body.slice(5)
							fetch(`https://api.areltiyan.site/sticker_maker?text=${ttptext}`, { method: 'GET'})
							.then(async res => {
							const ttptxt = await res.json()
							console.log("xazion")
							base64Img.img(ttptxt.base64, 'temp', 'ttp', function(err, filepath) {
							if (err) return console.log(err);
							exec(`ffmpeg -i ${pngttp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${webpng}`, (err) => {
							buffer = fs.readFileSync(webpng)
							xazion.sendMessage(from, buffer, sticker)
							fs.unlinkSync(webpng)
							fs.unlinkSync(pngttp)
							})
							})
							});
				   await limitAdd(sender)
	     	break
           case 'pornhub':
                    if (isPublic) return reply(tyro.botoff())              
                    if (isBanned) return reply(tyro.bUser())
    				if (!isRegistered) return reply(tyro.noregis())
    				if (isLimit(sender)) return reply(tyro.limitend(pusname))
    				var gh = body.slice(9)
    				var porn = gh.split("|")[0];
    				var hub = gh.split("|")[1];
    				if (args.length < 1) return reply(`example : ${prefix}pornhub xVraZ | Hub`)
    				reply(tyro.wait())
    				alan = await getBuffer(`https://vinz.zeks.xyz/api/pornhub?text1=${porn}&text2=${hub}`)
    				xazion.sendMessage(from, alan, image, {quoted: mek})
    			await limitAdd(sender)
				break
		case 'textlight':
                if (isPublic) return reply(tyro.botoff())                
                if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))				
				if (args.length < 1) return reply(tyro.wrongf())
				ligh = body.slice(11)
				if (ligh.length > 10) return reply('The text is long, up to 9 characters')
				reply(tyro.wait())
				lawak = await getBuffer(`https://api.zeks.xyz/api/tlight?text=${ligh}&apikey=apivinz`)
		        xazion.sendMessage(from, lawak, image, {quoted: mek})
		    await limitAdd(sender)
		    break
          case 'glitchtext':
                if (isPublic) return reply(tyro.botoff())                
                if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					var gh = body.slice(12)
					var gli = gh.split("|")[0];
					var tch = gh.split("|")[1];
					if (args.length < 1) return reply(`example : ${prefix}glitchtext xVraZ | include`)
					reply(tyro.wait())
					buffer = await getBuffer(`https://api.zeks.xyz/api/gtext?text1=${gli}&text2=${tch}&apikey=apivinz`)
					xazion.sendMessage(from, buffer, image, {quoted: mek})
				await limitAdd(sender)
				break
		case 'toimg':
                if (isPublic) return reply(tyro.botoff())			
            	if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
				if (!isQuotedSticker) return reply('Reply or Tag the sticker that you want to make a picture')
					reply(tyro.wait())
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await xazion.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${media} ${ran}`, (err) => {
						fs.unlinkSync(media)
						if (err) return reply(tyro.stikga())
						buffer = fs.readFileSync(ran)
						xazion.sendMessage(from, buffer, image, {quoted: mek, caption: '*convert success...*'})
						fs.unlinkSync(ran)
					})
				await limitAdd(sender)
				break
				case 'tomp3': //PERMIUM LIST ADD
                   if (isPublic) return reply(tyro.botoff())           
                   if (isBanned) return reply(tyro.bUser())
                   if (!isRegistered) return reply(tyro.noregis())
			       if (!isPrem) return reply(tyro.premium())
			       if (isLimit(sender)) return reply(tyro.limitend(pusname))
                	xazion.updatePresence(from, Presence.composing) 
				   if (!isQuotedVideo) return reply('*please reply to the video*')
					reply(tyro.wait())
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await xazion.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.mp4')
					exec(`ffmpeg -i ${media} ${ran}`, (err) => {
						fs.unlinkSync(media)
						if (err) return reply('yeah failed, please try again later')
						rmln = fs.readFileSync(ran)
						xazion.sendMessage(from, rmln, audio, {mimetype: 'audio/mp4', quoted: mek})
						fs.unlinkSync(ran)
					}) 
			   await limitAdd(sender)
			break
			 case 'nulis1':
                if (isPublic) return reply(tyro.botoff()) 
                if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
				if (args.length < 1) return reply(`*where is the text?* *Example : ${prefix}nulis1 hello world*`)
				xazions = body.slice(8)
				reply('*please wait.....🍃*')
				buff = await getBuffer(`https://api.xteam.xyz/magernulis1?text=${xazions}&APIKEY=${XteamKey}`)
				xazion.sendMessage(from, buff, image, {quoted: mek, caption: '*managed to write in books*'})
				await limitAdd(sender)
			break
				case 'nulis2': //PREMIUM LIST ADD
                if (isPublic) return reply(tyro.botoff())
                if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (!isPrem) return reply(tyro.premium())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
				if (args.length < 1) return reply(`*where is the text?* *Example : ${prefix}nulis2 hello world*`)
				laysha = body.slice(8)
				reply('*please wait.....🍃*')
				buff = await getBuffer(`https://api.xteam.xyz/magernulis3?text=${laysha}&APIKEY=${XteamKey}`)
				xazion.sendMessage(from, buff, image, {quoted: mek, caption: '*managed to write in books*'})
				await limitAdd(sender)
			break
	case 'ninjalogo':
    if (isPublic) return reply(tyro.botoff())              
    if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
				var gh = body.slice(11)
				var nin = gh.split("|")[0];
				var ja = gh.split("|")[1];
				if (args.length < 1) return reply(`example : ${prefix}ninjalogo xazion | include `)
				reply(tyro.wait())
				buffer = await getBuffer(`https://api.xteam.xyz/textpro/ninjalogo?text=${nin}&text2=${ja}&APIKEY=${XteamKey}`)
		    xazion.sendMessage(from, buffer, image, {quoted: mek})
		    await limitAdd(sender)
					break				
	case 'halloweentext':
                if (isPublic) return reply(tyro.botoff())            
                if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
				if (args.length < 1) return reply(tyro.wrongf())
				ween = body.slice(15)
				if (ween.length > 10) return reply('The text is long, up to 9 characters')
				reply(tyro.wait())
				buffer = await getBuffer(`https://api.xteam.xyz/textpro/helloweenfire?text=${ween}&APIKEY=${XteamKey}`)
		    xazion.sendMessage(from, buffer, image, {quoted: mek})
		    await limitAdd(sender)
		    break	
		    case 'neontext':
                    if (isPublic) return reply(tyro.botoff())           
                    if (isBanned) return reply(tyro.bUser())
			    	if (!isRegistered) return reply(tyro.noregis())
			    if (isLimit(sender)) return reply(tyro.limitend(pusname))
					if (args.length < 1) return reply(`「❗」Contoh : ${prefix}neontext xazion`)
					neon = body.slice(10)
					reply('*please wait a moment....🍃*')
					anu = await getBuffer(`https://api.xteam.xyz/textpro/neon?text=$APIKEY=${XteamKey}`)
					xazion.sendMessage(from, anu, image, {quoted: mek})
					await limitAdd(sender)
			break
			case 'cloudtext':
       if (isPublic) return reply(tyro.botoff())                
       if (isBanned) return reply(tyro.bUser())
   				if (!isRegistered) return reply(tyro.noregis())
   				if (isLimit(sender)) return reply(tyro.limitend(pusname))
       if (args.length < 1) return reply(`example : ${prefix}cloudtext xazion`)
       cloud = body.slice(11)
       reply('....')
       buffer = await getBuffer(`https://api.xteam.xyz/textpro/cloudtext?text=${cloud}&APIKEY=${XteamKey}`)
    xazion.sendMessage(from, buffer, image, {quoted: mek})
    break
    case 'tts':
  if (isPublic) return reply(tyro.botoff())			
  	if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
				if (args.length < 1) return xazion.sendMessage(from, 'language code is required, for example: $ {prefix} tts en xVraZ ', text, {quoted: mek})
					const gtts = require('./library/gtts')(args[0])
					if (args.length < 2) return xazion.sendMessage(from, `example : ${prefix}tts id iyahh yameteh`, text, {quoted: mek})
					dtt = body.slice(8)
					ranm = getRandom('.mp3')
					rano = getRandom('.ogg')
					dtt.length > 300
					? reply('The text is to long')
					: gtts.save(ranm, dtt, function() {
						exec(`ffmpeg -i ${ranm} -ar 48000 -vn -c:a libopus ${rano}`, (err) => {
							fs.unlinkSync(ranm)
							buff = fs.readFileSync(rano)
							if (err) return reply(tyro.stikga())
							xazion.sendMessage(from, buff, audio, {quoted: mek, ptt:true})
							fs.unlinkSync(rano)
						})
					})
					await limitAdd(sender)
					break
/**********************ALL LIST COMMAND******************/
		/*	case 'premiumlist':
  if (isPublic) return reply(tyro.botoff())				
  let listPremi = '「 *PREMIUM USER LIST* 」\n\n'

	                const deret = getAllPremiumUser()
	                const arrayPremi = []
	                for (let i = 0; i < deret.length; i++) {
	                    const checkExp = ms(getPremiumExpired(deret[i]) - Date.now())
	                    arrayPremi.push(getAllPremiumUser()[i])
	                    listPremi += `@${prem.split('@')[0]}\n➸ *Expired*: ${checkExp.days} day(s) ${checkExp.hours} hour(s) ${checkExp.minutes} minute(s)\n\n`
	                }
	                await reply(listPremi)
	            break*/
	            case 'stickerlist':
				case 'liststicker':
				if (isPublic) return reply(tyro.botoff()) 
				if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
					teks = '*Sticker List :*\n\n'
					for (let awokwkwk of setiker) {
						teks += `- ${awokwkwk}\n`
					}
					teks += `\n*Total : ${setiker.length}*`
					xazion.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": setiker } })
					break
	            case 'listbadword':
                    if (isPublic) return reply(tyro.botoff()) 
		                		if (isBanned) return reply(tyro.bUser())
                    let lbw = `Ini adalah list BAD WORD\nTotal : ${bad.length}\n`
                    for (let i of bad) {
                        lbw += `➸ ${i.replace(bad)}\n`
                    }
                    await reply(lbw)
                    await limitAdd(sender)
                    break 
	            case 'leaderboard':
            	case 'lb':
  if (isPublic) return reply(tyro.botoff())				
  if (isPublic) return reply(tyro.botoff())				
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (!isGroup) return reply(tyro.groupo())
				_level.sort((a, b) => (a.xp < b.xp) ? 1 : -1)
				uang.sort((a, b) => (a.uang < b.uang) ? 1 : -1)
                let leaderboardlvl = '-----[ *LEADERBOARD LEVEL* ]----\n\n'
                let leaderboarduang = '-----[ *LEADERBOARD MONEY* ]----\n\n'
                let nom = 0
                try {
                    for (let i = 0; i < 10; i++) {
                        nom++
                        leaderboardlvl += `*[${nom}]* wa.me/${_level[i].id.replace('@s.whatsapp.net', '')}\n┗⊱ *XP*: ${_level[i].xp} *Level*: ${_level[i].level}\n`
                        leaderboarduang += `*[${nom}]* wa.me/${uang[i].id.replace('@s.whatsapp.net', '')}\n┣⊱ *Uang*: _Rp${uang[i].uang}_\n`
                    }
                    await reply(leaderboardlvl)
                    await reply(leaderboarduang)
                } catch (err) {
                    console.error(err)
                    await reply(`minimal 10 user untuk bisa mengakses database`)
                }
					break
	       	case 'premiumlist':
	        	xazion.updatePresence(from, Presence.composing) 
	        	          if (isPublic) return reply(tyro.botoff())		
                    if (isBanned) return reply(tyro.bUser())
                    if (!isRegistered) return reply(tyro.noregis())
                    if (isLimit(sender)) return reply(tyro.limitend(pusname))
					teks = `╭─「 *TOTAL USER PREMIUM* 」\n`
					no = 0
					for (let prem of premium) {
						no += 1
						teks += `│「${no.toString()}」 @${prem.split('@')[0]}\n`
					}
					teks += `│ Total User Premium : ${premium.length}\n╰──────「 *${botName}* 」`
				xazion.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": premium}})
				break
   
/*********************** NSFW MENU ***********************/
case 'nekopoi':
  if (isPublic) return reply(tyro.botoff())
   if (isBanned) return reply(tyro.bUser())             		
			if (!isRegistered) return reply(tyro.noregis())
			if (isLimit(sender)) return reply(tyro.limitend(pusname))
			if (!isNsfw) return reply(tyro.nsfwoff())
			if (!isGroup) return reply(tyro.groupo()) 
              	    if (args.length < 1) return reply('teksnya mana gan?')
                    teks = body.slice(9)
                    anu = await fetchJson(`https://api.vhtear.com/nekosearch?query=${teks}&apikey=${apivhtear}`, {method: 'get'})
			reply(tyro.wait())
                    teks = `===============\n`
                    for (let neko of anu.result) {
                    teks += `Title: ${neko.title}\nDeskripsi: ${neko.detail}\n===============\n`
                    }
                    reply(teks.trim())
			     	await limitAdd(sender) 
			     	break  
			     			case 'nsfwloli':
  			try {
  			if (isPublic) return reply(tyro.botoff())	
				if (isBanned) return reply(tyro.bUser())   
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
				if (!isNsfw) return reply(tyro.nsfwoff())
				if (!isGroup) return reply(tyro.groupo()) 
				res = await fetchJson(`https://api.vhtear.com/randomloli&apikey=${apivhtear}`, {method: 'get'})
					reply(tyro.wait())
					buffer = await getBuffer(res.result.result)
					xazion.sendMessage(from, buffer, image, {quoted: mek, caption: '*warning NsfW*'})
				} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply(' *ERROR* ')
				}
					await limitAdd(sender)
					break 
				case 'ero':
  try {
		        if (isPublic) return reply(tyro.botoff())		           
				                    if (isBanned) return reply(tyro.bUser())
                        if (!isRegistered) return reply(tyro.noregis())
                        if (isLimit(sender)) return reply(tyro.limitend(pusname))
                        if (!isNsfw) return reply(tyro.nsfwoff())
						axios.get(`https://nekos.life/api/v2/img/ero`).then((res)=>{
						imageToBase64(res.data.url).then((response) => {var buf = Buffer.from(response, 'base64');
					xazion.sendMessage(from, buf, image, {quoted: mek,caption: "*warning NsfW*"})
					})})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('*ERROR*')
					}
					break
			case 'nsfwpussy':
  try {
		        if (isPublic) return reply(tyro.botoff())		
				    if (isBanned) return reply(tyro.bUser())
					if (!isRegistered) return reply(tyro.noregis())
                        if (isLimit(sender)) return reply(tyro.limitend(pusname))
                        if (!isNsfw) return reply(tyro.nsfwoff())
						axios.get(`https://nekos.life/api/v2/img/pussy_jpg`).then((res)=>{
						imageToBase64(res.data.url).then((response) => {var buf = Buffer.from(response, 'base64');
					xazion.sendMessage(from, buf, image, {quoted: mek,caption: "*warning NsfW*"})
					})})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('*ERROR*')
					}
					break
			case 'nsfwyuri':
		    try {
		        if (isPublic) return reply(tyro.botoff())		
				    if (isBanned) return reply(tyro.bUser())
					if (!isRegistered) return reply(tyro.noregis())
                        if (isLimit(sender)) return reply(tyro.limitend(pusname))
                        if (!isNsfw) return reply(tyro.nsfwoff())
						axios.get(`https://nekos.life/api/v2/img/yuri`).then((res)=>{
						imageToBase64(res.data.url).then((response) => {var buf = Buffer.from(response, 'base64');
					xazion.sendMessage(from, buf, image, {quoted: mek,caption: "*warning NsfW*"})
					})})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('*ERROR*')
					}
					break
			case 'nsfwtrap':
  try {
		        if (isPublic) return reply(tyro.botoff())		
				    if (isBanned) return reply(tyro.bUser())
					if (!isRegistered) return reply(tyro.noregis())
                        if (isLimit(sender)) return reply(tyro.limitend(pusname))
                        if (!isNsfw) return reply(tyro.nsfwoff())
						res = await fetchJson(`https://tobz-api.herokuapp.com/api/nsfwtrap?apikey=${tobzapi}`, {method: 'get'})
						buffer = await getBuffer(res.result)
						xazion.sendMessage(from, buffer, image, {quoted: mek, caption: '*warning NsfW*'})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('*ERROR*')
					}
					break
			case 'nsfwloli2':
  try {
		        if (isPublic) return reply(tyro.botoff())		
				    if (isBanned) return reply(tyro.bUser())
					if (!isRegistered) return reply(tyro.noregis())
                        if (isLimit(sender)) return reply(tyro.limitend(pusname))
                        if (!isNsfw) return reply(tyro.nsfwoff())
						res = await fetchJson(`https://api.lolis.life/random?nsfw=true`, {method: 'get'})
						buffer = await getBuffer(res.url)
						xazion.sendMessage(from, buffer, image, {quoted: mek, caption: '*warning NsfW*'})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('*ERROR*')
					}
					break
			case 'lewd':
  try {
		        if (isPublic) return reply(tyro.botoff())		
				    if (isBanned) return reply(tyro.bUser())
					if (!isRegistered) return reply(tyro.noregis())
                        if (isLimit(sender)) return reply(tyro.limitend(pusname))
                        if (!isNsfw) return reply(tyro.nsfwoff())
						axios.get(`https://nekos.life/api/v2/img/solo`).then((res)=>{
						imageToBase64(res.data.url).then((response) => {var buf = Buffer.from(response, 'base64');
					xazion.sendMessage(from, buf, image, {quoted: mek,caption: "*warning NsfW*"})
					})})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply('❌ *ERROR* ❌')
					}
					break
				case 'nsfwneko':
try {
		        if (isPublic) return reply(tyro.botoff())		
				if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pushname))
				if (!isNsfw) return reply(tyro.nsfwoff())
						res = await fetchJson(`https://tobz-api.herokuapp.com/api/nsfwneko?apikey=${tobzapi}`, {method: 'get'})
						buffer = await getBuffer(res.result)
						xazion.sendMessage(from, buffer, image, {quoted: mek, caption: '*warning NsfW*'})
					} catch (e) {
						console.log(`Error :`, color(e,'red'))
						reply(' *ERROR* ')
					}
					await limitAdd(sender) 
					break 
	case 'bokep':             
             	xazion.updatePresence(from, Presence.composing) 
       		     if (isPublic) return reply(tyro.botoff())		
                 if (isBanned) return reply(tyro.bUser())
		         if (!isRegistered) return reply(tyro.noregis())
		         	if (!isNsfw) return reply(tyro.nsfwoff())
				 data = fs.readFileSync('./src/18.js');
                 jsonData = JSON.parse(data);
                 randIndex = Math.floor(Math.random() * jsonData.length);
                 randKey = jsonData[randIndex];
                 randBokep = await getBuffer(randKey.image)
                 reply('warning NsfW')
                 randTeks = randKey.teks
                 xazion.sendMessage(from, randBokep, image, {quoted: mek, caption: randTeks})
			break										
     case 'randomhentai':
                   if (isPublic) return reply(tyro.botoff())            
                   if (isBanned) return reply(tyro.bUser())
	    	       if (!isRegistered) return reply(tyro.noregis())
	    	       	if (!isNsfw) return reply(tyro.nsfwoff())
					gatauda = body.slice(15)
					reply(tyro.wait())
					buffer = await getBuffer(`https://api.xteam.xyz/randomimage/hentai?APIKEY=${XteamKey}`)
					xazion.sendMessage(from, buffer, image, {quoted: mek})
			break	    	
	case 'blowjob':
                   if (isPublic) return reply(tyro.botoff())            
                   if (isBanned) return reply(tyro.bUser())
		    	   if (!isRegistered) return reply(tyro.noregis())
				   if (!isGroup) return reply(tyro.groupo())
                   if (!isNsfw) return reply(tyro.nsfwoff())
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/nsfwblowjob?apikey=${tobzapi}`, {method: 'get'})
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(tyro.stikga())
						buffer = fs.readFileSync(rano)
						xazion.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
		    break    				
 /********************** TOOLS MENU *************/
                  case 'lyrics':
  if (isPublic) return reply(tyro.botoff())              
  if (isPublic) return reply(tyro.botoff())              
  if (isPublic) return reply(tyro.botoff())              
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())      
                 		if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pushname))
					teks = body.slice(7)
					anu = await fetchJson(`http://scrap.terhambar.com/lirik?word=${teks}`, {method: 'get'})
					reply('Title '+teks+' Lyrics :\n\n'+anu.result.lirik)
				   await limitAdd(sender)    
            break       
            	case 'ssweb':
  if (isPublic) return reply(tyro.botoff())          	 
   if (isBanned) return reply(tyro.bUser())      
                if (!isRegistered) return reply(tyro.noregis())
                if (isLimit(sender)) return reply(tyro.limitend(pushname))                
					if (args.length < 1) return reply('where is the url?')
					teks = body.slice(7)
					reply(tyro.wait())
					anu = await fetchJson(`https://mnazria.herokuapp.com/api/screenshotweb?url=${teks}`)
					buff = await getBuffer(anu.gambar)
					xazion.sendMessage(from, buff, image, {quoted: mek})					
					await limitAdd(sender)    
            break                           
					case 'chord':
  if (isPublic) return reply(tyro.botoff())		
  			if (isBanned) return reply(tyro.bUser())
		if (!isRegistered) return reply(tyro.noregis())
		if (isLimit(sender)) return reply(tyro.limitend(pushname))
                anu = await fetchJson(`https://tobz-api.herokuapp.com/api/chord?q=${body.slice(7)}&apikey=${tobzapi}`)
                xazion.sendMessage(from, anu.result, text, {quoted:mek})
                await limitAdd(sender) 
                break
				case 'addsticker':
				if (isPublic) return reply(tyro.botoff()) 
				if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (!isQuotedSticker) return reply('Reply stiker nya')
					svst = body.slice(12)
					if (!svst) return reply('Nama sticker nya apa?')
					boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
					delb = await xazion.downloadMediaMessage(boij)
					setiker.push(`${svst}`)
					fs.writeFileSync(`./DB/sticker/${svst}.webp`, delb)
					fs.writeFileSync(`./DB/stik.json`, JSON.stringify(setiker))
					xazion.sendMessage(from, `Sukses Menambahkan Sticker\nCek dengan cara ${prefix}liststicker`, MessageType.text, { quoted: mek })
					await limitAdd(sender)
					break
       		          
     case 'getsticker':
				case 'gets':
				if (!isRegistered) return reply(tyro.noregis())
				if (isPublic) return reply(tyro.botoff()) 
				if (isBanned) return reply(tyro.bUser())
					namastc = body.slice(12)
					result = fs.readFileSync(`./DB/sticker/${namastc}.webp`)
					xazion.sendMessage(from, result, sticker, {quoted :mek})
					await limitAdd(sender)
					break
 case 'delete':
				case 'del':
				case 'd':
				xazion.deleteMessage(from, { id: mek.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: from, fromMe: true }) 
				await limitAdd(sender)
				break 
				case 'mining':
                      if (!isRegistered) return reply(tyro.noregis())
                      if (isLimit(sender)) return reply(tyro.limitend(pushname))
                      if (!isEventon) return reply(`Sorry ${pushname} event mining not activated by admin`)
                      if (isOwner) {
                      const one = 999999999
                      addLevelingXp(sender, one)
                      addLevelingLevel(sender, 99)
                      reply(`because you are our owner of the bot ${one}Xp for you`)
                      }else{
                      const mining = Math.ceil(Math.random() * 500)
                      addLevelingXp(sender, mining)
                      await reply(`*news* ${pushname} you get *${mining}Xp*`)
                      }
					await limitAdd(sender)    
            break
                      case 'leave':
  if (isPublic) return reply(tyro.botoff())                  
    if (isBanned) return reply(tyro.bUser())      
                      if (!isRegistered) return reply(tyro.noregis())           
                      if (!isGroup) return reply(tyro.groupo())
                      if (!isGroupAdmins) return reply(tyro.admin())
                      setTimeout( () => {
                      xazion.groupLeave (from) 
                      }, 2000)
                      setTimeout( () => {
                      xazion.updatePresence(from, Presence.composing) 
                      if (!isRegistered) return reply(tyro.noregis())
                      if (isBanned) return reply(tyro.bUser())   
                      xazion.sendMessage(from, 'Sayonara...', text)
                      }, 0)
                      break
 	case 'infogroup':
  if (isPublic) return reply(tyro.botoff())          	
   if (isBanned) return reply(tyro.bUser())
				if (isLimit(sender)) return reply(tyro.limitend(pushname))
                if (!isRegistered) return reply(tyro.noregis())
                if (!isGroup) return reply(tyro.groupo())
                ppUrl = await xazion.getProfilePicture(from) // leave empty to get your own
			    buffer = await getBuffer(ppUrl)
		        xazion.sendMessage(from, buffer, image, {quoted: mek, caption: `*NAME* : ${groupName}\n*MEMBER* : ${groupMembers.length}\n*ADMIN* : ${groupAdmins.length}\n*DESC* : ${groupDesc}`})
            break           	
 case 'admin':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))			
					if (!isGroup) return reply(tyro.groupo())
					teks = `*founding father GROUP* _${groupMetadata.subject}_\n*TOTAL* : ${groupAdmins.length}\n\n`
					no = 0
					for (let admon of groupAdmins) {
						no += 1
						teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
					}
					mentions(teks, groupAdmins, true)
					break
 		case 'spambrutal':
  if (isPublic) return reply(tyro.botoff())					
  if (isBanned) return reply(tyro.bUser())
			if (isLimit(sender)) return reply(tyro.limitend(pusname))
					if (!isRegistered) return reply(tyro.noregis())
						if (!isPrem) return reply(tyro.premium())                
						await limitAdd(sender)
                                       if (args[0].startsWith('08')) return reply('Use prefix numbers 8/n ex : *8796662*')
                                       if (args[0].startsWith('82255123081')) return reply('Failed unable to call bot number ')
                                       if (args[0].startsWith('82387804410')) return reply('Failed, unable to call owner number')
                                       reply('waiting....')
                                       var data = body.slice(12)
                                       await fetchJson(`https://core.ktbs.io/v2/user/registration/otp/62`+data, {method: 'get'})
                                       await fetchJson(`https://arugaz.herokuapp.com/api/spamcall?no=`+data, {method: 'get'})
                                       await fetchJson(`https://api.danacita.co.id/users/send_otp/?mobile_phone=62`+data, {method: 'get'})
                                       await fetchJson(`https://account-api-v1.klikindomaret.com/api/PreRegistration/SendOTPSMS?NoHP=0`+data, {method: 'get'})
                                       await fetchJson(`https://zeksapi.herokuapp.com/api/spamcall?no=`+data+`&apikey=${zeksapi}`, {method: 'get'})
                                       break
					case 'spamcall':
  if (isPublic) return reply(tyro.botoff())				
  	if (isBanned) return reply(tyro.bUser())
					if (!isRegistered) return reply(tyro.noregis())
						if (!isPrem) return reply(tyro.premium())
		if (isLimit(sender)) return reply(tyro.limitend(pusname))
		await limitAdd(sender)
                                       if (args[0].startsWith('08')) return reply('Use prefix numbers 8/n ex : *8796662*')
                                       if (args[0].startsWith('82255123081')) return reply('Failed unable to call the bot number')
                                       if (args[0].startsWith('82387804410')) return reply('Failed, unable to call owner number')
                                       reply('waiting....')
                                       var data = body.slice(10)
                                       await fetchJson(`https://core.ktbs.io/v2/user/registration/otp/62`+data, {method: 'get'})
                                       await fetchJson(`https://arugaz.herokuapp.com/api/spamcall?no=`+data, {method: 'get'})
                                       await fetchJson(`https://api.danacita.co.id/users/send_otp/?mobile_phone=62`+data, {method: 'get'})
                                       await fetchJson(`https://account-api-v1.klikindomaret.com/api/PreRegistration/SendOTPSMS?NoHP=0`+data, {method: 'get'})
                                       await fetchJson(`https://api-zeks.harispoppy.com/api/spamcall?no=`+data+`&apikey=${zeksapi}`, {method: 'get'})
                                       break
    case 'timer':
        if (isPublic) return reply(tyro.botoff())                
        if (isBanned) return reply(tyro.bUser())
    				if (!isRegistered) return reply(tyro.noregis())
    				if (isLimit(sender)) return reply(tyro.limitend(pusname))                  
    				if (args[1]=="second") {var timer = args[0]+"000"
				} else if (args[1]=="minutes") {var timer = args[0]+"0000"
				} else if (args[1]=="hours") {var timer = args[0]+"00000"
				} else {return reply("*select:*\nsecond\nminutes\nhours/nexample : ${prefix}timer 3 second")}
				setTimeout( () => {
				reply("pipipipip timer is over!")
				}, timer)
				await limitAdd(sender)
				break						                               
	/*********************FUN MENU*******************/
	
	case 'dice':
  if (isPublic) return reply(tyro.botoff())       
  		 if (isBanned) return reply(tyro.bUser())      
				if (!isRegistered) return reply(tyro.noregis())
                if (isLimit(sender)) return reply(tyro.limitend(pushname))
					kapankah = body.slice(1)
					const luya =['1','2','3','4','5','6']
					const leu = luya[Math.floor(Math.random() * luya.length)]
					xazion.sendMessage(from, leu, text, { quoted: mek })
					await limitAdd(sender)    
            break                
				case 'quotes':
  if (isPublic) return reply(tyro.botoff())			
  	xazion.updatePresence(from, Presence.composing) 
                if (isBanned) return reply(tyro.bUser())
                if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
				 data = fs.readFileSync('./src/quote.json');
                 jsonData = JSON.parse(data);
                 randIndex = Math.floor(Math.random() * jsonData.length);
                 randKey = jsonData[randIndex];
                 randQuote =''+randKey.quote+ '\n\n_By: '+randKey.by+'_'
                 xazion.sendMessage(from, randQuote, text, {quoted: mek})
				 await limitAdd(sender)
				 break				
				
					case 'meme':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
                if (!isRegistered) return reply(tyro.noregis())
                if (isLimit(sender)) return reply(tyro.limitend(pusname))
					nganu = await fetchJson(`https://vinz.zeks.xyz/api/meme`)
					buper = await getBuffer(nganu.result)
					xazion.sendMessage(from, buper, image, {quoted: mek})
					await limitAdd(sender)
					break						
case 'cry':
                    if (isPublic) return reply(tyro.botoff())            
                    if (isBanned) return reply(tyro.bUser())
			    	if (!isRegistered) return reply(tyro.noregis())			
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/cry?apikey=${tobzapi}`, {method: 'get'})
					reply('')
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(tyro.stikga())
						buffer = fs.readFileSync(rano)
						xazion.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
			break
	 ;
	case 'kiss':
                  if (isPublic) return reply(tyro.botoff())              
                  if (isBanned) return reply(tyro.bUser())
		  		  if (!isRegistered) return reply(tyro.noregis())
					ranp = getRandom('.gif')
					rano = getRandom('.webp')
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/kiss?apikey=${tobzapi}`, {method: 'get'})
					reply('')
					if (anu.error) return reply(anu.error)
					exec(`wget ${anu.result} -O ${ranp} && ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${rano}`, (err) => {
						fs.unlinkSync(ranp)
						if (err) return reply(tyro.stikga())
						buffer = fs.readFileSync(rano)
						xazion.sendMessage(from, buffer, sticker, {quoted: mek})
						fs.unlinkSync(rano)
					})
					await limitAdd(sender)
	    	break									
	case 'fitnah': ////PREMIUM LIST ADD
                if (isPublic) return reply(tyro.botoff())             
                if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (!isPrem) return reply(tyro.premium())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))				
					if (!isGroup) return reply(tyro.groupo())                 
				if (args.length < 1) return reply(`Contoh : ${prefix}fitnah [@tag|pesan|balasanbot]\n\nContoh : ${prefix}fitnah @tagmember&hai&hai juga`)
				var gh = body.slice(8)
				mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					var replace = gh.split("|")[0];
					var target = gh.split("|")[1];
					var bot = gh.split("|")[2];
					xazion.sendMessage(from, `${bot}`, text, {quoted: { key: { fromMe: false, participant: `${mentioned}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target}` }}})
					await limitAdd(sender)
					break					
case 'bisakah':
  if (isPublic) return reply(tyro.botoff())		
  		if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					bisakah = body.slice(1)
					const bisa =['Tentu Saja Bisa! Kamu Adalah Orang Paling menghoki','ga','au dah','Coba ulangi']
					const keh = bisa[Math.floor(Math.random() * bisa.length)]
					xazion.sendMessage(from, 'Question : *'+bisakah+'*\n\nAnswer : '+ keh, text, { quoted: mek })
					await limitAdd(sender)
					break
					case 'kapankah':
  if (isPublic) return reply(tyro.botoff())			
  	if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					kapankah = body.slice(1)
					const kapan =['Besok','Lusa','Tadi','4 Hari Lagi','5 Hari Lagi','6 Hari Lagi','1 Minggu Lagi','2 Minggu Lagi','3 Minggu Lagi','1 Bulan Lagi','2 Bulan Lagi','3 Bulan Lagi','4 Bulan Lagi','5 Bulan Lagi','6 Bulan Lagi','1 Tahun Lagi','2 Tahun Lagi','3 Tahun Lagi','4 Tahun Lagi','5 Tahun Lagi','6 Tahun Lagi','1 Abad lagi','3 Hari Lagi']
					const koh = kapan[Math.floor(Math.random() * kapan.length)]
					xazion.sendMessage(from, 'Question : *'+kapankah+'*\n\nAnswer : '+ koh, text, { quoted: mek })
					await limitAdd(sender)
					break
           case 'apakah':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
           if (!isRegistered) return reply(tyro.noregis())
           if (isLimit(sender)) return reply(tyro.limitend(pusname))
					apakah = body.slice(1)
					const apa =['Iya','Tidak','Bisa Jadi','coba ulangi']
					const kah = apa[Math.floor(Math.random() * apa.length)]
					xazion.sendMessage(from, 'Question : *'+apakah+'*\n\nAnswer : '+ kah, text, { quoted: mek })
					await limitAdd(sender)
					break
				case 'rate':
  if (isPublic) return reply(tyro.botoff())		
  		if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					rate = body.slice(1)
					const ra =['4','9','17','28','34','48','59','62','74','83','97','100','29','94','75','82','41','39']
					const te = ra[Math.floor(Math.random() * ra.length)]
					xazion.sendMessage(from, 'Question : *'+rate+'*\n\nJawaban : '+ te+'%', text, { quoted: mek })
					await limitAdd(sender)
					break
					
           case 'hobby':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
           if (!isRegistered) return reply(tyro.noregis())
           if (isLimit(sender)) return reply(tyro.limitend(pusname))
					hobby = body.slice(1)
					const hob =['Desah Di Game','Ngocokin Doi','Stalking sosmed nya mantan','Kau kan gak punya hobby ','Memasak','Membantu Atok','Mabar','Nobar','Sosmedtan','Membantu Orang lain','Nonton Anime','Nonton Drakor','Naik Motor','Nyanyi','Menari','Bertumbuk','Menggambar','Foto fotoan Ga jelas','Maen Game','Berbicara Sendiri']
					const by = hob[Math.floor(Math.random() * hob.length)]
					xazion.sendMessage(from, 'Question : *'+hobby+'*\n\nJawaban : '+ by, text, { quoted: mek })
					await limitAdd(sender)
					break
						case 'game':
  if (isPublic) return reply(tyro.botoff())				
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					anu = await fetchJson(`https://api.zeks.xyz/api/tebakgambar?apikey=apivinz`, {method: 'get'})
					ngebuff = await getBuffer(anu.result.soal)
					tebak = `➸ Jawaban : *${anu.result.jawaban}*`
					setTimeout( () => {
					xazion.sendMessage(from, tebak, text, {quoted: mek})
					}, 30000) // 1000 = 1s,
					setTimeout( () => {
					xazion.sendMessage(from, '_10 sec...._', text) // ur cods
					}, 20000) // 1000 = 1s,
					setTimeout( () => {
					xazion.sendMessage(from, '_20 sec..._', text) // ur cods
					}, 10000) // 1000 = 1s,
					setTimeout( () => {
					xazion.sendMessage(from, '_30 sec..._', text) // ur cods
					}, 2500) // 1000 = 1s,
					setTimeout( () => {
					xazion.sendMessage(from, ngebuff, image, { caption: 'please answer the guess', quoted: mek }) // ur cods
					}, 0) // 1000 = 1s,
					await limitAdd(sender) 
					break
					case 'seberapagay':
  if (isPublic) return reply(tyro.botoff())	
  	if (isBanned) return reply(tyro.benned)    
				 if (!isRegistered) return reply(tyro.noregis())
           if (isLimit(sender)) return reply(tyro.limitend(pusname))
		if (args.length < 1) return reply('tag temanmu!')
					rate = body.slice(13)
					const ti =['4','9','17','28','34','48','59','62','74','83','97','100','29','94','75','82','41','39']
					const kl = ti[Math.floor(Math.random() * ti.length)]
					xazion.sendMessage(from, '*Seberapa gay*'+rate+'*\n\nPresentase : '+ kl+'%', text, { quoted: mek })
					await limitAdd(sender)
					break
                case 'truth':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
                if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					const trut =['coba ceritain hal memalukan apa aja yang kamu masih inget sampai sekarang','suka ngapain aja si kalo sendirian dirumah?','pernah ngelakuin apa aja setiap sendiri dirumah dan ngapain aja buat mengisi rasa gabut mu','Pernah suka sama siapa aja? berapa lama?','Kalau boleh atau kalau mau, di gc/luar gc siapa yang akan kamu jadikan sahabat?(boleh beda/sma jenis)','apa ketakutan terbesar kamu?','pernah suka sama orang dan merasa orang itu suka sama kamu juga?','Siapa nama mantan pacar teman mu yang pernah kamu sukai diam diam?','pernah gak nyuri uang nyokap atau bokap? Alesanya?','hal yang bikin seneng pas lu lagi sedih apa','pernah cinta bertepuk sebelah tangan? kalo pernah sama siapa? rasanya gimana brou?','pernah jadi selingkuhan orang?','hal yang paling ditakutin','siapa orang yang paling berpengaruh kepada kehidupanmu','hal membanggakan apa yang kamu dapatkan di tahun ini','siapa orang yang bisa membuatmu sange','siapa orang yang pernah buatmu sange','(bgi yg muslim) pernah ga solat seharian?','Siapa yang paling mendekati tipe pasangan idealmu di sini','suka mabar(main bareng)sama siapa?','pernah nolak orang? alasannya kenapa?','Sebutkan kejadian yang bikin kamu sakit hati yang masih di inget','pencapaian yang udah didapet apa aja ditahun ini?','kebiasaan terburuk lo pas di sekolah apa?']
					const ttrth = trut[Math.floor(Math.random() * trut.length)]
					truteh = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
					xazion.sendMessage(from, truteh, image, { caption: '*Truth*\n\n'+ ttrth, quoted: mek })
					await limitAdd(sender)
					break
                case 'dare':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))                
					const dare =['ungkapin perasaan mu  sekarang terhadap orang yang kamu sukai','papa dan kirim ke orang yang terakhir kali kamu chat dengan caption  i love u','bilangNGE NIH KAMU NUDES DONG ke orang yang terakhir kali kamu chat','Kirim pesan ke mantan kamu dan bilang "aku masih suka sama kamu','telfon crush/pacar sekarang dan ss ke pemain','pap ke salah satu anggota grup','Bilang "KAMU CANTIK BANGET NGGAK BOHONG" ke cowo','ss recent call whatsapp','drop emot 🤥 setiap ngetik di gc/pc selama 1 hari','kirim voice note bilang can i call u xazion?','drop kutipan lagu/quote, terus tag member yang cocok buat kutipan itu','pake foto sule sampe 3 hari','ketik pake bahasa daerah 24 jam','ganti nama menjadi "gue anak lucinta luna" selama 5 jam','chat ke kontak wa urutan sesuai %batre kamu, terus bilang ke dia "i lucky to hv you','prank chat mantan dan bilang " i love u, pgn balikan','record voice baca surah al-kautsar','bilang "i hv crush on you, mau jadi pacarku gak?" ke lawan jenis yang terakhir bgt kamu chat (serah di wa/tele), tunggu dia bales, kalo udah ss drop ke sini','sebutkan tipe pacar mu!','snap/post foto pacar/crush','teriak gajelas lalu kirim pake vn kesini','pap mukamu lalu kirim ke salah satu temanmu','kirim fotomu dengan caption, aku anak pungut','teriak pake kata kasar sambil vn trus kirim kesini','teriak " anjimm gabutt anjimmm " di depan rumah mu','ganti nama jadi " BOWO " selama 24 jam','Pura pura kerasukan, contoh : kerasukan maung, kerasukan belalang, kerasukan kulkas, dll']
					const der = dare[Math.floor(Math.random() * dare.length)]
					tod = await getBuffer(`https://i.ibb.co/305yt26/bf84f20635dedd5dde31e7e5b6983ae9.jpg`)
					xazion.sendMessage(from, tod, image, { quoted: mek, caption: '*Dare*\n\n'+ der })
					await limitAdd(sender)
					break
/******************* GRAMBLING MENU *****************/
					case 'spin':
  if (isPublic) return reply(tyro.botoff())			
  	if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					bisakah = body.slice(1)
					const bisas =['0','1','2','3','4','4','5','6','7','8','9','10','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50']
					const kehh = bisas[Math.floor(Math.random() * bisas.length)]
					xazion.sendMessage(from, kehh, text, { quoted: mek })
					await limitAdd(sender)
					break
					case 'push':
  if (isPublic) return reply(tyro.botoff())				
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					bisakah = body.slice(1)
					const bisasv =['0','1','2','3','4','4','5','6','7','8','9','10','10','11','12','13','14','15','16','17','18','19','20','21']				
						const kehhv = bisasv[Math.floor(Math.random() * bisasv.length)]
					xazion.sendMessage(from, kehhv, text, { quoted: mek })
					await limitAdd(sender)
					break
					
				/*	case 'bet':
  if (isPublic) return reply(tyro.botoff())			
  	if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					bisakah = body.slice(6)
					xazion.sendMessage(from, 'Bet number : ', bisakah, text, { quoted: mek })
					await limitAdd(sender)
					break
					case 'slot':
  if (isPublic) return reply(tyro.botoff())				
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					const keh3 = ['🍓', '🍉', '🍌']
					const kehhh = keh3[Math.floor(Math.random() * keh3.length)
					xazion.sendMessage(from, '🎰「', kehhh, '」', text, { quoted: mek })
					await limitAdd(sender)
					break*/		
					
  
					
/*********************INFO MENU**************/
case 'limit':
  if (isPublic) return reply(tyro.botoff())				               
     if (isBanned) return reply(tyro.bUser())
				   if (!isRegistered) return reply(tyro.noregis())
				   checkLimit(sender)
					break
				case 'pay':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())				
				if (!isRegistered) return reply(tyro.noregis())
				if (!q.includes('|')) return  reply(tyro.wrongf())
				if (args.length < 1) return reply('example : ${prefix}pay @taguser|2000')
                const tujuan = q.substring(0, q.indexOf('|') - 1)
                const jumblah = q.substring(q.lastIndexOf('|') + 1)
                if(isNaN(jumblah)) return await reply('only number can allowed!!')
                if (checkATMuser(sender) < jumblah) return reply(`your money is not enough`)
                const tujuantf = `${tujuan.replace("@", '')}@s.whatsapp.net`
                fee = 0.005 *  jumblah
                hasiltf = jumblah - fee
                addKoinUser(tujuantf, hasiltf)
                confirmATM(sender, jumblah)
                addKoinUser('6289601007614@s.whatsapp.net', fee)
                reply(`*⟪ Success ⟫*
                money transfer was successful
                ➸ from : +${sender.split("@")[0]}
                ➸ to : +${tujuan}
                ➸ total transfer : *$${jumblah}*
                ➸ tax PPN : *$${fee}*`)
                break
				case 'atm':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())				
				if (!isRegistered) return reply(tyro.noregis())
				const kantong = checkATMuser(sender)
				reply(tyro.uangkau(pushname, sender, kantong))
				break
				case 'buylimit':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())				
				if (!isRegistered) return reply(tyro.noregis())
				if (args.length < 1) return reply('example : ${prefix}buylimit (total number u want to buy limit)')
				payout = body.slice(10)
				if(isNaN(payout)) return await reply('only number can allowed!!')
				const koinPerlimit = 100000
				const total = koinPerlimit * payout
				if ( checkATMuser(sender) <= total) return reply(`your money is not enough`)
				if ( checkATMuser(sender) >= total ) {
					confirmATM(sender, total)
					bayarLimit(sender, payout)
					await reply(`*⟪ SUCCESSFUL PAYMENT ⟫*
					➸ Limit : Tyro inc
					➸ receiver : ${pushname}
					➸ nominal purchase : *$${payout}*
					➸ Price limit : ${koinPerlimit}/limit
					➸  : ${checkATMuser(sender)}
					ID : ${createSerial(15)}`)
				} 
				break
				case 'giftlimit': 
				if (!isOwner,!isPrem) return reply(tyro.premium(pushname))
				const nomerr = args[0].replace('@','')
                const jmla = args[1]
                if (jmla <= 1) return reply(`minimal gift limit adalah 1`)
                if (isNaN(jmla)) return reply(`limit harus berupa angka`)
                if (!nomerr) return reply(`maaf format salah\nmasukan parameter yang benar\ncontoh : ${prefix}giftlimit @62895710074883 20`)
                const cysz = nomerr + '@s.whatsapp.net'
                var found = false
                        Object.keys(_limit).forEach((i) => {
                            if(_limit[i].id === cysz){
                                found = i
                            }
                        })
                        if (found !== false) {
                            _limit[found].limit -= jmla
                            const updated = _limit[found]
                            const result = `Gift kuota limit sukses dengan SN: ${createSerial(8)} pada ${moment().format('DD/MM/YY HH:mm:ss')}
*「 GIFT KUOTA LIMIT 」*

• User : @${updated.id.replace('@s.whatsapp.net','')}
• Limit: ${limitawal-updated.limit}`
                            console.log(_limit[found])
                            fs.writeFileSync('./DB/user/limit.json',JSON.stringify(_limit));
                            reply(result)
                        } else {
                                reply(`Maaf, nomor ${nomerr} tidak terdaftar di database!`)
                        }
                break
/***************SOSMED MENU****************/
case 'mutual':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (!isPrem) return reply(tyro.premium())
                if (isGroup) return  reply( 'cannot use in group')
                anug = getRegisteredRandomId(_registered).replace('@s.whatsapp.net','')
                await reply('looking for a partner.......')
                await reply(`wa.me/${anug}`)
                await reply( `Partner found: \n*${prefix}next* — to continue`)
            break
            case 'next':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (!isPrem) return reply(tyro.premium())
                if (isGroup) return  reply( 'cannot use in group')
                anug = getRegisteredRandomId(_registered).replace('@s.whatsapp.net','')
                await reply('looking for a partner.......')
                await reply(`wa.me/${anug}`)
                await reply( `Partner found : \n*${prefix}next* — to continue`)
                break
/*********************STALKER MENU*******************/
      case 'stalkig':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
                   if (!isRegistered) return reply(tyro.noregis())
                   if (isLimit(sender)) return reply(tyro.limitend(pusname))
                     teks = body.slice(9)
                     anu = await fetchJson(`https://api.xteam.xyz/dl/igstalk?nama=${teks}&APIKEY=${XteamKey}`, {method: 'get'})
                     reply('*Please wait a moment.....🍃*')
                     buffer = await getBuffer(anu.result.user.hd_profile_pic_url_info.url)
                     hasil = `USERNAME ${teks} \n\n *Username?* : _${anu.result.user.username}_ \n *Name??* : _${anu.result.user.full_name}_ \n *Follower??﹦?* : _${anu.result.user.follower_count}_ \n *Following?* : _${anu.result.user.following_count}_ \n *Post?* : _${anu.result.user.media_count}_ \n *Bioi?? :* _${anu.result.user.biography}`
                    xazion.sendMessage(from, buffer, image, {quoted: mek, caption: hasil})
                    await limitAdd(sender)
			       break
/************ PARAMETER MENU *********/
case 'nobadword':
     if (isPublic) return reply(tyro.botoff()) 
				if (isBanned) return reply(tyro.bUser())
                    if (!isGroup) return reply(tyro.groupo())
                if (!isGroupAdmins) return reply(tyro.admin())
                if (args.length < 1) return reply('Boo :??')
                if (args[0] === 'enable') {
                if (isBadWord) return reply('*fitur BadWord sudah aktif sebelum nya*')
                 	   badword.push(from)
                 	   fs.writeFileSync('./DB/group/badword.json', JSON.stringify(badword))
                  	   reply(`badword is enable`)
              	  } else if (args[0] === 'disable') {
                  	  badword.splice(from, 1)
                 	   fs.writeFileSync('./DB/group/badword.json', JSON.stringify(badword))
                 	    reply(`badword is disable`)
             	   } else {
                 	   reply(tyro.satukos())
                	}
                    break				         
case 'bot':
    	 if (isBanned) return reply(tyro.bUser())				
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					if (args.length < 1) return reply('params enable/disable')
					if (args[0] === 'off') {
						if (isPublic) return reply('Already Activating')
						publik.push(from)
						fs.writeFileSync('./DB/group/public.json', JSON.stringify(publik))
						reply(`Success Now Members Cannot Use Bot`)
					} else if (args[0] === 'on') {
						publik.splice(from, 1)
						fs.writeFileSync('./DB/group/public.json', JSON.stringify(publik))
						reply(`Success now you can use the feature ${prefix}help`)
					} else {
						reply('select on / off')
					}
					break
						case 'obot':
    	 if (isBanned) return reply(tyro.bUser())				
					if (!isGroup) return reply(tyro.groupo())	
  if (!isOwner) return reply(tyro.owners())
					if (args.length < 1) return reply('params enable/disable')
					if (args[0] === 'off') {
						if (isPublic) return reply('Already Activating')
						publik.push(from)
						fs.writeFileSync('./DB/group/public.json', JSON.stringify(publik))
						reply(`Success Now Members Cannot Use Bot`)
					} else if (args[0] === 'on') {
						publik.splice(from, 1)
						fs.writeFileSync('./DB/group/public.json', JSON.stringify(publik))
						reply(`Success now you can use the feature ${prefix}help`)
					} else {
						reply('select on / off')
					}
					break		
case 'welcome':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())				
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					if (args.length < 1) return reply('*example : ${prefix}welcome enable/disable*')
					if (args[0] === 'enable') {
						if (isWelkom) return reply('*the welcome feature has been activated*')
						welkom.push(from)
						fs.writeFileSync('./DB/group/welkom.json', JSON.stringify(welkom))
						reply('*successfully the welcome feature has been activated*')
					} else if (args[0] === 'disable') {
						welkom.splice(from, 1)
						fs.writeFileSync('./DB/group/welkom.json', JSON.stringify(welkom))
						reply('*successfully turned off the welcome feature*')
					} else {
						reply(tyro.satukos())
					}
					break			
					case 'anime':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())				
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					if (args.length < 1) return reply('*example : ${prefix}anime enable/disable*')
					if (args[0] === 'enable') {
						if (isWelkom) return reply('*the anime feature has been activated*')
						animes.push(from)
						fs.writeFileSync('./DB/anime/anime.json', JSON.stringify(welkom))
						reply('*successfully the anime feature has been activated*')
					} else if (args[0] === 'disable') {
						animes.splice(from, 1)
						fs.writeFileSync('./DB/anime/anime.json', JSON.stringify(welkom))
						reply('*successfully turned off the anime feature*')
					} else {
						reply(tyro.satukos())
					}
					break			
					case 'owelcome':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())				
					if (!isGroup) return reply(tyro.groupo())
					if (!isOwner) return reply(tyro.owners())
					if (args.length < 1) return reply('*example : ${prefix}owelcome enable/disable*')
					if (args[0] === 'enable') {
						if (isWelkom) return reply('*the welcome feature has been activated*')
						welkom.push(from)
						fs.writeFileSync('./DB/group/welkom.json', JSON.stringify(welkom))
						reply('*successfully the welcome feature has been activated*')
					} else if (args[0] === 'disable') {
						welkom.splice(from, 1)
						fs.writeFileSync('./DB/group/welkom.json', JSON.stringify(welkom))
						reply('*successfully turned off the welcome feature*')
					} else {
						reply(tyro.satukos())
					}
					break			
case 'event':
     if (isPublic) return reply(tyro.botoff())                
     if (isBanned) return reply(tyro.bUser())                 
					if (!isGroup) return reply(tyro.groupo())
					if (!isOwner) return reply(tyro.owners())
					if (args.length < 1) return reply('*example : ${prefix}event enable/disable*')
					if (args[0] === 'enable') {
						if (isEventon) return reply('*ALREADY ACTIVE EVENT FEATURES*')
						event.push(from)
						fs.writeFileSync('./DB/group/event.json', JSON.stringify(event))
						reply('*successfully activated the event feature*')
					} else if (args[0] === 'disable') {
						event.splice(from, 1)
						fs.writeFileSync('./DB/group/event.json', JSON.stringify(event))
						reply('*successfully turned off the event feature*')
					} else {
						reply(tyro.satukos())
					}
					break
      case 'leveling':
                if (isPublic) return reply(tyro.botoff())           
                if (!isGroup) return reply(tyro.groupo())
                if (!isGroupAdmins) return reply(tyro.admin())
                if (args.length < 1) return reply('*example : ${prefix}event enable/disable*')
                if (args[0] === 'enable') {
                    if (isLevelingOn) return reply('*the level feature has been active before*')
                    _leveling.push(from)
                    fs.writeFileSync('./DB/group/leveling.json', JSON.stringify(_leveling))
                     reply(tyro.lvlon())
                } else if (args[0] === 'disable') {
                    _leveling.splice(from, 1)
                    fs.writeFileSync('./DB/group/leveling.json', JSON.stringify(_leveling))
                     reply(tyro.lvloff())
                } else {
                    reply(tyro.satukos())
                }
					break
					 case 'oleveling':
  if (isPublic) return reply(tyro.botoff())           
     if (!isGroup) return reply(tyro.groupo())
                if (!isOwner) return reply(tyro.owners())
                if (args.length < 1) return reply('*example : ${prefix}event enable/disable*')
                if (args[0] === 'enable') {
                    if (isLevelingOn) return reply('*the level feature has been active before*')
                    _leveling.push(from)
                    fs.writeFileSync('./DB/group/leveling.json', JSON.stringify(_leveling))
                     reply(tyro.lvlon())
                } else if (args[0] === 'disable') {
                    _leveling.splice(from, 1)
                    fs.writeFileSync('./DB/group/leveling.json', JSON.stringify(_leveling))
                     reply(tyro.lvloff())
                } else {
                    reply(tyro.satukos())
                }
					break
					
				case 'nsfw':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())				
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					if (args.length < 1) return reply('*example : ${prefix}event enable/disable*')
					if (args[0] === 'enable') {
						if (isNsfw) return reply(' *Already Actived!*')
						nsfw.push(from)
						fs.writeFileSync('./DB/group/nsfw.json', JSON.stringify(nsfw))
						reply('*successfully activated the nsfw feature*')
					} else if (args[0] === 'disable') {
						nsfw.splice(from, 1)
						fs.writeFileSync('./DB/group/nsfw.json', JSON.stringify(nsfw))
						reply('*successfully turned off the nsfw feature*')
					} else {
						reply(tyro.satukos())
					}
					break
						case 'onsfw':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())				
					if (!isGroup) return reply(tyro.groupo())
				if (!isOwner) return reply(tyro.owners())
					if (args.length < 1) return reply('*example : ${prefix}event enable/disable*')
					if (args[0] === 'enable') {
						if (isNsfw) return reply(' *Already Actived!*')
						nsfw.push(from)
						fs.writeFileSync('./DB/group/nsfw.json', JSON.stringify(nsfw))
						reply('*successfully activated the nsfw feature*')
					} else if (args[0] === 'disable') {
						nsfw.splice(from, 1)
						fs.writeFileSync('./DB/group/nsfw.json', JSON.stringify(nsfw))
						reply('*successfully turned off the nsfw feature*')
					} else {
						reply(tyro.satukos())
					}
					break
      case 'antilink':
     if (isPublic) return reply(tyro.botoff())                
     if (isBanned) return reply(tyro.bUser())				
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					if (!isBotGroupAdmins) return reply(tyro.badmin())					
					if (args.length < 1) return reply('type enable to activating')
					if (args[0] === 'enable') {
						if (isAntiLink) return reply('??Already actived')
						antilink.push(from)
						fs.writeFileSync('./DB/group/antilink.json', JSON.stringify(antilink))
						reply('successfully activated the antilink feature')
						xazion.sendMessage(from,`ALLERT!!! If not admin dont send group link`, text)
					} else if (args[0] === 'disable') {
						if (!isAntiLink) return reply('has it been activated?')
						var ini = anti.botLangsexOf(from)
						antilink.splice(ini, 1)
						fs.writeFileSync('./DB/group/antilink.json', JSON.stringify(antilink))
						reply('managed to turn off group antilink')
					} else {
						reply('enable to activating disable to turn off')
					}
					break					
					case 'oantilink':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())				
					if (!isGroup) return reply(tyro.groupo())
				if (!isOwner) return reply(tyro.owners())
					if (!isBotGroupAdmins) return reply(tyro.badmin())					
					if (args.length < 1) return reply('type enable to activating')
					if (args[0] === 'enable') {
						if (isAntiLink) return reply('??Already actived')
						antilink.push(from)
						fs.writeFileSync('./DB/group/antilink.json', JSON.stringify(antilink))
						reply('successfully activated the antilink feature')
						xazion.sendMessage(from,`ALLERT!!! If not admin dont send group link`, text)
					} else if (args[0] === 'disable') {
						if (!isAntiLink) return reply('has it been activated?')
						var ini = anti.botLangsexOf(from)
						antilink.splice(ini, 1)
						fs.writeFileSync('./DB/group/antilink.json', JSON.stringify(antilink))
						reply('managed to turn off group antilink')
					} else {
						reply('enable to activating disable to turn off')
					}
					break					
					case 'grup':
					case 'group':
     if (isPublic) return reply(tyro.botoff())					
     if (isPublic) return reply(tyro.botoff())                
     if (isBanned) return reply(tyro.bUser())					
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					if (!isBotGroupAdmins) return reply(tyro.badmin())
					if (args.length < 1) return reply('example : ${prefix}group open/closed')
					if (args[0] === 'open') {
					    reply(`*SUCCESSFUL OPENING THE GROUP*`)
						xazion.groupSettingChange(from, GroupSettingChange.messageSend, false)
					} else if (args[0] === 'closed') {
						reply(`*SUCCESSFUL CLOSING THE GROUP*`)
						xazion.groupSettingChange(from, GroupSettingChange.messageSend, true)
					}
					break
/************************* ADMIN MENU ***********************/
				case 'add':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())	
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					if (!isBotGroupAdmins) return reply(tyro.badmin())
					if (args.length < 1) return reply('Who do you want to add??')
					if (args[0].startsWith('08')) return reply('Use the language code')
					try {
						num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
						xazion.groupAdd(from, [num])
					} catch (e) {
						console.log('Error :', e)
						reply('can not enter numbers into the wrong number group or indeed in private')
					}
					break
			     	case 'kick':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())	     	
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					if (!isBotGroupAdmins) return reply(tyro.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('𝗧𝗮𝗴 𝘁𝗮𝗿𝗴𝗲𝘁 ??𝗮𝗻𝗴 𝗶𝗻𝗴𝗶𝗻 𝗱𝗶 𝘁𝗲𝗻𝗱𝗮𝗻𝗴!')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let _ of mentioned) {
							teks += `Good bye 🏃 :\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						xazion.groupRemove(from, mentioned)
					} else {
						mentions(`Good bye @${mentioned[0].split('@')[0]} 🏃`, mentioned, true)
						xazion.groupRemove(from, mentioned)
					}
					break					
                case 'hidetag':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())                
                if (!isRegistered) return reply(tyro.noregis())
                if (isLimit(sender)) return reply(tyro.limitend(pusname))
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					var value = body.slice(9)
					var group = await xazion.groupMetadata(from)
					var member = group['participants']
					var mem = []
					member.map( async adm => {
					mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
					})
					var options = {
					text: value,
					contextInfo: { mentionedJid: mem },
					quoted: mek
					}
					xazion.sendMessage(from, options, text)
					await limitAdd(sender)
					break					
					 case 'hideping':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())                
                if (!isRegistered) return reply(tyro.noregis())
                if (isLimit(sender)) return reply(tyro.limitend(pusname))
					if (!isGroup) return reply(tyro.groupo())
					if (!isPrem) return reply(tyro.premium())
					var value = body.slice(9)
					var group = await xazion.groupMetadata(from)
					var member = group['participants']
					var mem = []
					member.map( async adm => {
					mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
					})
					var options = {
					text: value,
					contextInfo: { mentionedJid: mem },
					quoted: mek
					}
					xazion.sendMessage(from, options, text)
					await limitAdd(sender)
					break					
                case 'level':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())                
                if (!isRegistered) return reply(tyro.noregis())
                if (!isLevelingOn) return reply(tyro.lvlnoon())
                if (!isGroup) return reply(tyro.groupo())
                const userLevel = getLevelingLevel(sender)
                const userXp = getLevelingXp(sender)
                if (userLevel === undefined && userXp === undefined) return reply(tyro.lvlnul())
                const requiredXp = 5000 * (Math.pow(2, userLevel) - 1)
                resul = `┏━━━━━━♡ *LEVEL* ♡━━━━━━━┓\n┃╭───────────────────\n┃│➸ NAME : ${pushname}\n┃│➸ Number : wa.me/${sender.split("@")[0]}\n┃│➸ XP : ${userXp}/${requiredXp}\n┃│➸ LEVEL : ${userLevel}\n┃╰───────────────────\n┗━━━━━━━━━━━━━━━━━━━━┛`
               xazion.sendMessage(from, resul, text, { quoted: mek})
                .catch(async (err) => {
                        console.error(err)
                        await reply(`Error!\n${err}`)
                    })
					break
                 case 'linkgroup':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))                
				    if (!isGroup) return reply(tyro.groupo())
				    if (isLimit(sender)) return reply(tyro.limitend(pusname))
				    if (!isBotGroupAdmins) return reply(tyro.badmin())
				    linkgc = await xazion.groupInviteCode (from)
				    yeh = `https://chat.whatsapp.com/${linkgc}\n\nlink Group *${groupName}*`
				    xazion.sendMessage(from, yeh, text, {quoted: mek})
			        await limitAdd(sender)
					break
				case 'ping':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))		
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `@${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					await limitAdd(sender)
					break
					case 'ping1':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))		
					if (!isGroup) return reply(tyro.groupo())
				if (!isPrem) return reply(tyro.premium())
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `➸ @${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					await limitAdd(sender)
					break
           case 'setname':
  if (isPublic) return reply(tyro.botoff())            
    if (!isRegistered) return reply(tyro.noregis())           
                if (!isGroup) return reply(tyro.groupo())
			    if (!isGroupAdmins) return reply(tyro.admin())
				if (!isBotGroupAdmins) return reply(tyro.badmin())
                xazion.groupUpdateSubject(from, `${body.slice(9)}`)
                xazion.sendMessage(from, '*success*', text, {quoted: mek})
					break
                case 'setdesc':
  if (isPublic) return reply(tyro.botoff())            
    if (!isRegistered) return reply(tyro.noregis())                
                if (!isGroup) return reply(tyro.groupo())
			    if (!isGroupAdmins) return reply(tyro.admin())
				if (!isBotGroupAdmins) return reply(tyro.badmin())
                xazion.groupUpdateDescription(from, `${body.slice(9)}`)
                xazion.sendMessage(from, '*success*', text, {quoted: mek})
					break
           case 'demote':
  if (isPublic) return reply(tyro.botoff())             
   if (!isRegistered) return reply(tyro.noregis())           
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					if (!isBotGroupAdmins) return reply(tyro.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('𝗧𝗮𝗴 𝘁𝗮𝗿𝗴𝗲𝘁 𝘆𝗮𝗻𝗴 𝗶𝗻𝗴𝗶𝗻 𝗱𝗶 𝘁𝗲𝗻𝗱𝗮𝗻𝗴!')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let _ of mentioned) {
							teks += `demoted :\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						xazion.groupDemoteAdmin(from, mentioned)
					} else {
						mentions(`demoted @${mentioned[0].split('@')[0]}`, mentioned, true)
						xazion.groupDemoteAdmin(from, mentioned)
					}
					break
				case 'promote':
  if (isPublic) return reply(tyro.botoff())            
    if (!isRegistered) return reply(tyro.noregis())				
					if (!isGroup) return reply(tyro.groupo())
					if (!isGroupAdmins) return reply(tyro.admin())
					if (!isBotGroupAdmins) return reply(tyro.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('𝗧𝗮𝗴 ??𝗮??𝗴𝗲𝘁 𝘆𝗮𝗻𝗴 𝗶𝗻𝗴𝗶𝗻 𝗱𝗶 𝘁𝗲𝗻𝗱𝗮𝗻𝗴!')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let _ of mentioned) {
							teks += `promoted :\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						xazion.groupMakeAdmin(from, mentioned)
					} else {
						mentions(`promoted @${mentioned[0].split('@')[0]}`, mentioned, true)
						xazion.groupMakeAdmin(from, mentioned)
					}
					break
/********************************************** OWNER MENU ***************************************/      
      case 'addbadword':
                    if (!isOwner) return reply(tyro.owners())
                    if (args.length < 1) return reply( `Kirim perintah ${prefix}addbadword [kata kasar]. contoh ${prefix}addbadword bego`)
                    const bw = body.slice(12)
                    bad.push(bw)
                    fs.writeFileSync('./DB/group/bad.json', JSON.stringify(bad))
                    reply('Success Menambahkan Bad Word!')
                    break
      case 'delbadword':
                    if (!isOwner) return reply(tyro.owners())
                    if (args.length < 1) return reply( `Kirim perintah ${prefix}addbadword [kata kasar]. contoh ${prefix}addbadword bego`)
                    let dbw = body.slice(12)
                    bad.splice(dbw)
                    fs.writeFileSync('./DB/group/bad.json', JSON.stringify(bad))
                    reply('Success Menghapus BAD WORD!')
                    break 			
      case 'addprem':
               					if (!isOwner) return reply(tyro.owners())
		               			addp = body.slice(10)
               					premium.push(`${addp}@s.whatsapp.net`)
 		              			fs.writeFileSync('./DB/user/premium.json', JSON.stringify(premium))
	               				reply(`managed to add ${addp} to premium user`)
               					break
	  			case 'dellprem':
              					if (!isOwner) return reply(tyro.owners())
	              				oh = body.slice(11)
              					delp = premium.indexOf(oh)
	              				premium.splice(delp, 1)
	              				fs.writeFileSync('./DB/user/premium.json', JSON.stringify(premium))
		              			reply(`Successfully Delete ${oh} in Premium user`)
              					break					
 	 	 		case 'bc':
                   if (isPublic) return reply(tyro.botoff())					
                   xazion.updatePresence(from, Presence.composing) 
		          		     if (!isOwner) return reply(tyro.owners())
		              			if (args.length < 1) return reply('where is the text??')
              					anu = await xazion.chats.all()
		              			if (isMedia && !mek.message.videoMessage || isQuotedImage) {
		             				const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
				             		buff = await xazion.downloadMediaMessage(encmedia)
			             			for (let _ of anu) {
            							xazion.sendMessage(_.jid, buff, image, {caption: `*「 xazion BROADCAST 」*\n\n${body.slice(4)}`})
						}
            						reply('*waiting.....*')
					} else {
            						for (let _ of anu) {
					           		sendMess(_.jid, `*「 XAZION BROADCAST 」*\n\n${body.slice(4)}`)
    		   			}
	            					reply('*success*')
					}
				             	break
				case 'bcgc':
  if (isPublic) return reply(tyro.botoff())				    
   if (!isOwner) return reply(tyro.owners())
					if (args.length < 1) return reply('where is the text???')
					anu = await groupMembers
					nom = mek.participant
					if (isMedia && !mek.message.videoMessage || isQuotedImage) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						buff = await xazion.downloadMediaMessage(encmedia)
						for (let _ of anu) {
							xazion.sendMessage(_.jid, buff, image, {caption: `*「 BROADCAST 」*\n\n➸ From the Group : ${groupName}\n➸ Sender : wa.me/${(sender.split('@')[0])}\n➸ Msg : ${body.slice(6)}`})
						}
						reply('*success*')
					} else {
						for (let _ of anu) {
							sendMess(_.jid, `*「 BROADCAST 」*\n\n➸ From the group : ${groupName}\n➸ Sender : wa.me/${(sender.split('@')[0])}\n➸ Msg : ${body.slice(6)}`)
						}
						reply('*success*')
					}
					break
					case 'setreply':
  if (isPublic) return reply(tyro.botoff())		
  			if (!isOwner) return reply(tyro.owners())
                    xazion.updatePresence(from, Presence.composing) 
					if (args.length < 1) return
					cr = body.slice(10)
					reply(`reply berhasil di ubah menjadi : ${cr}`)
					await limitAdd(sender)
					break
				case 'setprefix':
  if (isPublic) return reply(tyro.botoff())				
  	if (args.length < 1) return
					if (!isOwner) return reply(tyro.owners())
					prefix = args[0]
					reply(`*「 SUKSES 」* Prefix jadi ➸ : ${prefix}`)
					break
				case 'clearall':
  if (isPublic) return reply(tyro.botoff())			
  		if (!isOwner) return reply(tyro.owners())
					anu = await xazion.chats.all()
					xazion.setMaxListeners(25)
					for (let _ of anu) {
						xazion.deleteChat(_.jid)
					}
					reply(tyro.clears())
					break
			       case 'block':
  if (isPublic) return reply(tyro.botoff())				 
  xazion.updatePresence(from, Presence.composing) 
				 xazion.chatRead (from)
					if (!isGroup) return reply(tyro.groupo())
					if (!isOwner) return reply(tyro.owners())
					xazion.blockUser (`${body.slice(7)}@c.us`, "add")
					xazion.sendMessage(from, `perintah Diterima, memblokir ${body.slice(7)}@c.us`, text)
					break
                    case 'unblock':
  if (isPublic) return reply(tyro.botoff())				
  	if (!isGroup) return reply(tyro.groupo())
					if (!isOwner) return reply(tyro.owners())
				    xazion.blockUser (`${body.slice(9)}@c.us`, "remove")
					xazion.sendMessage(from, `Perintah Diterima, membuka ${body.slice(9)}@c.us`, text)
					break   				
					case 'setppbot':
  if (isPublic) return reply(tyro.botoff())				
  	if (!isOwner) return reply(tyro.owners())
				    xazion.updatePresence(from, Presence.composing) 
					if (!isQuotedImage) return reply(`Kirim gambar dengan caption ${prefix}setbotpp atau tag gambar yang sudah dikirim`)
					enmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await xazion.downloadAndSaveMediaMessage(enmedia)
					await xazion.updateProfilePicture(botNumber, media)
					reply('success')
					break
				case 'clone':
  if (isPublic) return reply(tyro.botoff())			
  		if (!isGroup) return reply(tyro.groupo())
					if (!isOwner) return reply(tyro.ownerg())
					if (args.length < 1) return reply(' *TAG YANG MAU DI CLONE!!!* ')
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag cvk')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					let { jid, id, notify } = groupMembers.find(x => x.jid === mentioned)
					try {
						pp = await xazion.getProfilePicture(id)
						buffer = await getBuffer(pp)
						xazion.updateProfilePicture(botNumber, buffer)
						mentions(`Foto profile Berhasil di perbarui menggunakan foto profile @${id.split('@')[0]}`, [jid], true)
					} catch (e) {
						reply(tyro.stikga())
					}
					await limitAdd(sender)
					break
			                case 'ban':
  if (isPublic) return reply(tyro.botoff())				
  	if (!isOwner) return reply(tyro.owners())
					bnnd = body.slice(6)
					ban.push(`${bnnd}@s.whatsapp.net`)
					fs.writeFileSync('./DB/user/banned.json', JSON.stringify(ban))
					reply(`Number ${bnnd} got banned!`)
					break
				case 'unban':
  if (isPublic) return reply(tyro.botoff())				
  	if (!isOwner) return reply(tyro.owners())
					ya = body.slice(8)
					unb = ban.indexOf(ya)
					ban.splice(unb, 1)
					fs.writeFileSync('./DB/user/banned.json', JSON.stringify(ban))
					reply(`Number ${ya} got unban!`)
					break
				case 'resetlimit':
  if (isPublic) return reply(tyro.botoff())				
  if (!isOwner) return reply(tyro.owners())
				var SettingKey = []
				rest = _limit.indexOf([0])
				_limit.splice(rest)
				fs.writeFileSync('./DB/user/limit.json', JSON.stringify(SettingKey))
				reply(`success reset`)
				break									
			case 'oadd':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())	
					if (!isGroup) return reply(tyro.groupo())
				if (!isOwner) return reply(tyro.owners())
					if (!isBotGroupAdmins) return reply(tyro.badmin())
					if (args.length < 1) return reply('Who do you want to add??')
					if (args[0].startsWith('08')) return reply('Use the language code')
					try {
						nums = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
						xazion.groupAdd(from, [nums])
					} catch (e) {
						console.log('Error :', e)
						reply('can not enter numbers into the wrong number group or indeed in private')
					}
					break
			     	case 'okick':
 if (isPublic) return reply(tyro.botoff())                
  if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())	     	
					if (!isGroup) return reply(tyro.groupo())
					if (!isOwner) return reply(tyro.owners())
					if (!isBotGroupAdmins) return reply(tyro.badmin())
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('𝗧𝗮𝗴 𝘁𝗮𝗿𝗴𝗲𝘁 ??𝗮𝗻𝗴 𝗶𝗻𝗴𝗶𝗻 𝗱𝗶 𝘁𝗲𝗻𝗱𝗮𝗻𝗴!')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = ''
						for (let _ of mentioned) {
							teks += `Good bye 🏃 :\n`
							teks += `@_.split('@')[0]`
						}
						mentions(teks, mentioned, true)
						xazion.groupRemove(from, mentioned)
					} else {
						mentions(`Good bye @${mentioned[0].split('@')[0]} 🏃`, mentioned, true)
						xazion.groupRemove(from, mentioned)
					}
					break
/***************** WIBU MENU ***************/
  case 'ranime':
    if (isPublic) return reply(tyro.botoff())                
    if (isBanned) return reply(tyro.bUser())
    if (!isAnime) return reply(tyro.animes())      
				if (!isRegistered) return reply(tyro.noregis())
				if (isLimit(sender)) return reply(tyro.limitend(pushname))
					reply(tyro.wait())
					anu = await fetchJson(`https://tobz-api.herokuapp.com/api/randomanime?apikey=${tobzapi}`, {method: 'get'})
					buffer = await getBuffer(anu.result)
					xazion.sendMessage(from, buffer, image, {quoted: mek, caption: '*Tyro Including*'})
					await limitAdd(sender)    
            break	            
  case 'wanime':
                   if (isPublic) return reply(tyro.botoff()) 
		               		if (isBanned) return reply(tyro.bUser())
                   if (!isRegistered) return reply(tyro.noregis())
                   if (!isAnime) return reply(tyro.animes())
                   if (isLimit(sender)) return reply(tyro.limitend(pusname))
                   if (args.length < 1) return reply('*example : ${prefix}wanime kurumi*')
              					anu = await fetchJson(`https://api.fdci.se/rep.php?gambar=${body.slice(8)}`, {method: 'get'})
		              			reply(tyro.wait())
              					var n = JSON.parse(JSON.stringify(anu));
              					var nimek =  n[Math.floor(Math.random() * n.length)];
				              	pok = await getBuffer(nimek)
              					xazion.sendMessage(from, pok, image, { quoted: mek, caption: '*Tyro Including*' })
	              				await limitAdd(sender)
			              		break
	case 'wibu':
    if (isPublic) return reply(tyro.botoff())		
  		if (isBanned) return reply(tyro.bUser())
				if (!isRegistered) return reply(tyro.noregis())
				if (!isAnime) return reply(tyro.animes())
				if (isLimit(sender)) return reply(tyro.limitend(pusname))
					data = await fetchJson(`https://api.vhtear.com/randomwibu&apikey=${apivhtear}`)
					reply(tyro.wait())
					buffer = await getBuffer(data.result.foto)
					xazion.sendMessage(from, buffer, image, {quoted: mek, caption: '*Tyro Including*'})
					await limitAdd(sender)
					break                                      			
/****************** AFK MENU FUNC *************/
          		case 'afk':
                tels = body.slice(4)
                if (args.length < 1) return reply('afk reason?')
                if (!isRegistered) return reply(tyro.noregis())
                var num = mek.participant
                hidis =  "'"
                const fku = {
                text: `@${num.split("@s.whatsapp.net")[0]} *AFK ${tels} DON${hidis}T DISTURB YES*`,
                contextInfo: { mentionedJid: [num] }
                                        }
                xazion.sendMessage(from, fku, text, {quoted: mek})
            break                                        
        				case 'unafk':           
                 tels = body.slice(4)
                 if (args.length < 1) return reply('sucess!!?')
                 var num = mek.participant
                 const kl7 = {
                 text: `@${numm.split("@s.whatsapp.net")[0]} *HAVE BACK FROM AFK ${tels}*`,
                 contextInfo: { mentionedJid: [num] }
                                        }
                 xazion.sendMessage(from, kl7, text, {quoted: mek})
            break
/***************** END LOAD OF ALL CMD ***********/
default:
			if (body.startsWith(`${prefix}${command}`)) {

                  reply(`Sorry *${pushname}*, Command *${prefix}${command}* not listed in cmd *${prefix}help*`)

                  }
			if (isGroup && !isCmd != undefined) {
					//	console.log(budy)
						//muehe = await simih(budy)
				//		reply(tyro.cmdnf(prefix, command))
					} else {
						console.log(color('[ERROR]','red'), 'Unregistered Command from', color(sender.split('@')[0]))
					}
					}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})
/*
BACA UNLICENSE DARI KAMI AGAR KAMU BISA MEMAHAMI DAN MENJAGA SEMUA PROJECT KAMI
DAN JUGA KALIAN BEBAS MENGGUNAKAN SCRIPT INI*/