const a = "'"

exports.animes = () => {
 return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

  ⚠️ *ANIME FEATURE ENABLE* ⚠️

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.wait = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

   ⚠️ *PLEASE WAIT A MOMENT* ⚠️

━━━━━━━━━━━━━━━━━━━━━━━━`
}
exports.succes = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

          *✅SUCCESSFUL✅*

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.botoff = () => {
 return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

    ⚠️ *THE BOT IS OFF* ⚠️

━━━━━━━━━━━━━━━━━━━━━━━━
`}
exports.lvlon = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

    ⚠️ *ENABLE LEVELING* ⚠️
    
━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.lvloff = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

     ❌ *DISABLE LEVELING* ❌

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.lvlnul = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

   *YOUR LEVEL IS STILL EMPTY*

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.lvlnoon = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

      *GROUB LEVEL IS*
     *NOT ACTIVATED YET*
    
━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.noregis = () => {
	return`
━━━━━♡ *NOT REGISTERED* ♡━━━━━

 *how to register ${prefix}register name|age* 
 *exam ${prefix}register xazion|20*

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.bUser = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

   *you have been banned*
  *please contact us to unban*
 *and want to follow our rules*

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.premium = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

  *you are not a premium user*
 *you can${a}t use this command*

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.rediregis = () => {
	return`
━━━♡ *ALREADY REGISTERED* ♡━━━━━

   *you are already registered*
    *in the database bot tyro*

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.stikga = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

 *YEAH FAILED TRY AGAIN LATER*

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.linkga = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

     ⚠️ *INVALID LINK* ⚠️
     
━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.groupo = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

  ⚠️ *CMD GROUP ONLY* ⚠️

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.owners = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

  ⚠️ *OWNER BOT ONLY* ⚠️
  
━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.ownerg = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

  ⚠️ *CREATOR GROUP ONLY* ⚠️
    
━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.admin = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

  ⚠️ *ADMIN GROUP ONLY* ⚠️

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.badmin = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

    ⚠️ *BOT MUST BE ADMIN* ⚠️

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.nsfwoff = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

    ⚠️ *NSFW NOT ACTIVE* ⚠️
  
━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.bug = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

  *Problems have been reported*
        *to the BOT owner*
      
━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.wrongf = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

  *ERROR!! YOUR CMD IS WRONG*
  
━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.clears = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

     *CLEAR ALL CHAT IN THE*
        *DATA SUCCESS*
      
━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.pc = () => {
	return`
	
━━━━━♡ *REGISTRASION* ♡━━━━━━

*To find out if you have registered,*
*please check the message I sent*
*NOTE: if you havent got the message*
*means you haven${a}t saved*
     *your bot number*
     
━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.registered = (namaUser, umurUser, serialUser, time, sender, botName) => {
	return`
━━━♡ *SUCCESSFUL REGISTRASION* ♡━━━━

            	*User Info*              	
      
 	*➸ Name :* *${namaUser}*
  	
  *➸ Number :* *wa.me/${sender.split("@")[0]}*
 
 	*➸ age : ${umurUser}*
 	
	 *➸ Registration Date :* *${time}*
  
  *➸ ID :* *${serialUser}*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
	  `
}

exports.owneresce = (pushname) => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

❌ *sorry ${pushname} owner only* ❌

━━━━━━━━━━━━━━━━━━━━━━━━`
}
exports.levelup = (pushname, sender, getLevelingXp,  getLevel, getLevelingLevel) => {
	return`
━━━━♡ *you have leveled up* ♡━━━━━━

             *Info User*
                      
  ➸ *Name* : *${pushname}*

  ➸ *Number* : wa.me/${sender.split("@")[0]}

  ➸ *Xp required* : *${getLevelingXp(sender)}*

  ➸ *Level* : ${getLevel} ➸ ${getLevelingLevel(sender)}
  
━━━━━━━━━━━━━━━━━━━━━━━━━━
`}
 
exports.limitend = (pushname) => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

*Sorry ${pushname} Today is limit is up*
    *limit will be reset at 24:00*
    
━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.limitcount = (limitCounts) => {
	return`
━━━━━━♡ *LIMIT COUNT* ♡━━━━━

 *your limit : ${limitCounts}*
 *or Upgrade to premium user*
 *to use cmd with no limit*
 
━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.satukos = () => {
	return`
━━━━━━♡ *INFORMATION* ♡━━━━━━

   *add parameter enable/disable*

━━━━━━━━━━━━━━━━━━━━━━━━`
}

exports.uangkau = (pushname, sender, uangkau) => {
	return`
	┏━━━━━━━━♡ *ATM BOT* ♡━━━━━━━┓
	┃╭────────────────────────
	┃│➸ NAME : *${pushname}*
	┃│
	┃│➸ NUMBER : *${sender.split("@")[0]}*
	┃│
	┃│➸ MONEY : *$${uangkau}*
	┃╰────────────────────────
	┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
}

